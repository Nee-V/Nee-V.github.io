webpackJsonp([0],[
/* 0 */,
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(90)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(74),
  /* template */
  __webpack_require__(155),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */,
/* 13 */,
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(50),
  /* template */
  __webpack_require__(157),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 15 */,
/* 16 */,
/* 17 */,
/* 18 */,
/* 19 */,
/* 20 */,
/* 21 */,
/* 22 */,
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/01.f066f8c.jpg";

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/02.6c06d9e.jpg";

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/03.54aa350.jpg";

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/04.7bf203e.jpg";

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(91)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(54),
  /* template */
  __webpack_require__(156),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-2d76c1cd",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(92)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(56),
  /* template */
  __webpack_require__(160),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-3377d14c",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(57),
  /* template */
  __webpack_require__(169),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(99)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(58),
  /* template */
  __webpack_require__(167),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-5b221e81",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(115)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(59),
  /* template */
  __webpack_require__(186),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-ee1332c8",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(104)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(60),
  /* template */
  __webpack_require__(173),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-6c2b12ca",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(102)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(63),
  /* template */
  __webpack_require__(171),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-649521aa",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(94)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(64),
  /* template */
  __webpack_require__(162),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-42cbab62",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(68),
  /* template */
  __webpack_require__(158),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(106)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(69),
  /* template */
  __webpack_require__(176),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-76e94d18",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(89)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(72),
  /* template */
  __webpack_require__(154),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-04e4342c",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(101)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(73),
  /* template */
  __webpack_require__(170),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-626e0909",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(100)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(75),
  /* template */
  __webpack_require__(168),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-60aae370",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(98)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(77),
  /* template */
  __webpack_require__(166),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-5a1d4b7b",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 41 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue_router__ = __webpack_require__(188);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_core_Hello__ = __webpack_require__(138);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_core_Hello___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__components_core_Hello__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_core_Home__ = __webpack_require__(139);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_core_Home___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__components_core_Home__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_core_Breadcrumbs__ = __webpack_require__(29);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_core_Breadcrumbs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__components_core_Breadcrumbs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_core_DrilldownMenu__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_core_DrilldownMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__components_core_DrilldownMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_core_DropdownMenu__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_core_DropdownMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__components_core_DropdownMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_core_Magellan__ = __webpack_require__(33);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_core_Magellan___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__components_core_Magellan__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__components_core_Pagination__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_core_Slider__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_core_Slider___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__components_core_Slider__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_core_Tooltip__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_core_Tooltip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__components_core_Tooltip__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_blocks_BlogPostFooter__ = __webpack_require__(135);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_blocks_BlogPostFooter___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__components_blocks_BlogPostFooter__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_blocks_ProductCard__ = __webpack_require__(136);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_blocks_ProductCard___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__components_blocks_ProductCard__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__components_helpers_StandardMenu__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__components_helpers_StandardMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__components_helpers_StandardMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__components_pages_AccordionPage__ = __webpack_require__(147);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__components_pages_AccordionPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_14__components_pages_AccordionPage__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__components_pages_AccordionMenuPage__ = __webpack_require__(146);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__components_pages_AccordionMenuPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_15__components_pages_AccordionMenuPage__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__components_pages_Components__ = __webpack_require__(148);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__components_pages_Components___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_16__components_pages_Components__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__components_pages_DropdownPage__ = __webpack_require__(149);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__components_pages_DropdownPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_17__components_pages_DropdownPage__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__components_pages_TabsPage__ = __webpack_require__(152);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__components_pages_TabsPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_18__components_pages_TabsPage__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__components_pages_OrbitPage__ = __webpack_require__(150);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__components_pages_OrbitPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_19__components_pages_OrbitPage__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__components_pages_RevealPage__ = __webpack_require__(151);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__components_pages_RevealPage___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_20__components_pages_RevealPage__);
// Import Vue and Vue Router



// Custom Components



// Foundation Core Components







// import Dropdown from '@/components/core/Dropdown'
// import Orbit from '@/components/core/Orbit'
// import Reveal from '@/components/core/Reveal'
// import ToggleSwitch from '@/components/core/ToggleSwitch'
// import Tabs from '@/components/core/Tabs'

// Foundation Building Blocks




// Pages








// Initialize Vue Router
__WEBPACK_IMPORTED_MODULE_0_vue__["a" /* default */].use(__WEBPACK_IMPORTED_MODULE_1_vue_router__["a" /* default */])

/* harmony default export */ __webpack_exports__["a"] = (new __WEBPACK_IMPORTED_MODULE_1_vue_router__["a" /* default */]({
  mode: 'history',
  routes: [
    { name: 'standard-menu', path: '/standard-menu', component: __WEBPACK_IMPORTED_MODULE_13__components_helpers_StandardMenu___default.a },
    { name: 'components-page', path: '/components', component: __WEBPACK_IMPORTED_MODULE_16__components_pages_Components___default.a },
    { name: 'Hello', path: '/', component: __WEBPACK_IMPORTED_MODULE_2__components_core_Hello___default.a },
    { name: 'Home', path: '/components/home', component: __WEBPACK_IMPORTED_MODULE_3__components_core_Home___default.a },
    { name: 'accordion', path: '/components/accordion', component: __WEBPACK_IMPORTED_MODULE_14__components_pages_AccordionPage___default.a },
    { name: 'accordion-menu', path: '/components/accordion-menu', component: __WEBPACK_IMPORTED_MODULE_15__components_pages_AccordionMenuPage___default.a },
    { name: 'breadcrumbs', path: '/components/breadcrumbs', component: __WEBPACK_IMPORTED_MODULE_4__components_core_Breadcrumbs___default.a },
    { name: 'drilldown-menu', path: '/components/drilldown-menu', component: __WEBPACK_IMPORTED_MODULE_5__components_core_DrilldownMenu___default.a },
    { name: 'dropdown', path: '/components/dropdown', component: __WEBPACK_IMPORTED_MODULE_17__components_pages_DropdownPage___default.a },
    { name: 'dropdown-menu', path: '/components/dropdown-menu', component: __WEBPACK_IMPORTED_MODULE_6__components_core_DropdownMenu___default.a },
    { name: 'magellan', path: '/components/magellan', component: __WEBPACK_IMPORTED_MODULE_7__components_core_Magellan___default.a },
    { name: 'orbit', path: '/components/orbit', component: __WEBPACK_IMPORTED_MODULE_19__components_pages_OrbitPage___default.a },
    { name: 'pagination', path: '/components/pagination', component: __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination___default.a },
    { name: 'reveal', path: '/components/reveal', component: __WEBPACK_IMPORTED_MODULE_20__components_pages_RevealPage___default.a },
    { name: 'slider', path: '/components/slider', component: __WEBPACK_IMPORTED_MODULE_9__components_core_Slider___default.a },
    { name: 'tabs', path: '/components/tabs', component: __WEBPACK_IMPORTED_MODULE_18__components_pages_TabsPage___default.a },
    { name: 'tooltip', path: '/components/tooltip', component: __WEBPACK_IMPORTED_MODULE_10__components_core_Tooltip___default.a },
    { name: 'blog-post-footer', path: '/blog-post-footer', component: __WEBPACK_IMPORTED_MODULE_11__components_blocks_BlogPostFooter___default.a },
    { name: 'product-card', path: '/product-card', component: __WEBPACK_IMPORTED_MODULE_12__components_blocks_ProductCard___default.a }
  ]
}));


/***/ }),
/* 42 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vue__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vuex__ = __webpack_require__(190);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__state_js__ = __webpack_require__(87);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__getters_js__ = __webpack_require__(86);
// index.js





__WEBPACK_IMPORTED_MODULE_0_vue__["a" /* default */].use(__WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */])

/* harmony default export */ __webpack_exports__["a"] = (new __WEBPACK_IMPORTED_MODULE_1_vuex__["a" /* default */].Store({
  state: __WEBPACK_IMPORTED_MODULE_2__state_js__["a" /* state */],
  getters: __WEBPACK_IMPORTED_MODULE_3__getters_js__["a" /* getters */]
}));


/***/ }),
/* 43 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 44 */,
/* 45 */,
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(113)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(51),
  /* template */
  __webpack_require__(184),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _accountingJs = __webpack_require__(49);

var _accountingJs2 = _interopRequireDefault(_accountingJs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'vue-numeric',

  props: {
    /**
     * Currency symbol.
     */
    currency: {
      default: '',
      required: false,
      type: String
    },

    /**
     * Maximum value allowed.
     */
    max: {
      required: false,
      type: [Number, String]
    },

    /**
     * Minimum value allowed.
     */
    min: {
      default: 0,
      required: false,
      type: [Number, String]
    },

    /**
     * Enable/Disable minus value.
     */
    minus: {
      default: false,
      required: false,
      type: Boolean
    },

    /**
     * Input placeholder.
     */
    placeholder: {
      required: false,
      type: String
    },

    /**
     * Number of decimals.
     * Decimals symbol are the opposite of separator symbol.
     */
    precision: {
      required: false,
      type: [Number, String]
    },

    /**
     * Thousand separator type.
     * Separator props accept either . or , (default).
     */
    separator: {
      default: ',',
      required: false,
      type: String
    },

    /**
     * v-model value.
     */
    value: {
      required: true,
      type: [Number, String]
    },

    /**
     * Hide input and show value in text only.
     */
    readOnly: {
      default: false,
      required: false,
      type: Boolean
    },

    /**
     * Class for the span tag when readOnly props is true.
     */
    readOnlyClass: {
      default: '',
      required: false,
      type: String
    },

    /**
     * Position of currency symbol
     * Symbol position props accept either 'suffix' or 'prefix' (default).
     */
    currencySymbolPosition: {
      default: 'prefix',
      required: false,
      type: String
    }
  },

  data: function data() {
    return {
      amount: ''
    };
  },

  computed: {
    /**
     * Number formatted user typed value.
     * @return {Number}
     */
    amountValue: function amountValue() {
      return this.formatToNumber(this.amount);
    },


    /**
     * Number type from value props.
     * @return {Number}
     */
    numberValue: function numberValue() {
      return this.formatToNumber(this.value);
    },


    /**
     * Number formatted minimum value.
     * @return {Number}
     */
    minValue: function minValue() {
      if (this.min) return this.formatToNumber(this.min);
      return 0;
    },


    /**
     * Number formatted maximum value.
     * @return {Number|undefined}
     */
    maxValue: function maxValue() {
      if (this.max) return this.formatToNumber(this.max);
      return undefined;
    },


    /**
     * Define decimal separator based on separator props.
     * @return {String} '.' or ','
     */
    decimalSeparator: function decimalSeparator() {
      if (this.separator === '.') return ',';
      return '.';
    },


    /**
     * Define thousand separator based on separator props.
     * @return {String} '.' or ','
     */
    thousandSeparator: function thousandSeparator() {
      if (this.separator === '.') return '.';
      return ',';
    },


    /**
     * Define format for currency symbol and value.
     * @return {String} format
     */
    formatString: function formatString() {
      return this.currencySymbolPosition === 'suffix' ? '%v %s' : '%s %v';
    }
  },

  methods: {
    /**
     * Check provided value againts maximum allowed.
     * @param {Number} value
     * @return {Boolean}
     */
    checkMaxValue: function checkMaxValue(value) {
      if (this.max) {
        if (value <= this.maxValue) return false;
        return true;
      }
      return false;
    },


    /**
     * Check provided value againts minimum allowed.
     * @param {Number} value
     * @return {Boolean}
     */
    checkMinValue: function checkMinValue(value) {
      if (this.min) {
        if (value >= this.minValue) return false;
        return true;
      }
      return false;
    },


    /**
     * Format provided value to number type.
     * @param {String} value
     * @return {Number}
     */
    formatToNumber: function formatToNumber(value) {
      var number = 0;

      if (this.separator === '.') {
        var cleanValue = value;
        if (typeof value !== 'string') {
          cleanValue = this.numberToString(value);
        }
        number = Number(String(cleanValue).replace(/[^0-9-,]+/g, '').replace(',', '.'));
      } else {
        number = Number(String(value).replace(/[^0-9-.]+/g, ''));
      }

      if (!this.minus) return Math.abs(number);
      return number;
    },


    /**
     * Validate value before apply to the component.
     * @param {Number} value
     */
    processValue: function processValue(value) {
      if (isNaN(value)) {
        this.updateValue(this.minValue);
      } else if (this.checkMaxValue(value)) {
        this.updateValue(this.maxValue);
      } else if (this.checkMinValue(value)) {
        this.updateValue(this.minValue);
      } else {
        this.updateValue(value);
      }
    },


    /**
     * Format value using symbol and separator.
     */
    formatValue: function formatValue() {
      this.amount = _accountingJs2.default.formatMoney(this.numberValue, {
        symbol: this.currency,
        format: this.formatString,
        precision: Number(this.precision),
        decimal: this.decimalSeparator,
        thousand: this.thousandSeparator
      });
    },


    /**
     * Update parent component model value.
     * @param {Number} value
     */
    updateValue: function updateValue(value) {
      this.$emit('input', Number(_accountingJs2.default.toFixed(value, this.precision)));
    },


    /**
     * Remove symbol and separator.
     * @param {Number} value
     */
    numberToString: function numberToString(value) {
      return _accountingJs2.default.formatMoney(value, {
        symbol: '',
        precision: Number(this.precision),
        decimal: this.decimalSeparator,
        thousand: ''
      });
    },


    /**
     * Remove symbol and separator.
     * @param {Number} value
     */
    convertToNumber: function convertToNumber(value) {
      this.amount = this.numberToString(value);
    }
  },

  watch: {
    /**
     * Watch for value change from other input.
     *
     * @param {Number} val
     * @param {Number} oldVal
     */
    numberValue: function numberValue(val, oldVal) {
      if (this.amountValue !== val && this.amountValue === oldVal) {
        this.convertToNumber(val);
        if (this.$refs.numeric !== document.activeElement) {
          this.formatValue(val);
        }
      }
    },


    /**
     * When readOnly is true, replace the span tag class.
     *
     * @param {Boolean} val
     * @param {Boolean} oldVal
     */
    readOnly: function readOnly(val, oldVal) {
      var _this = this;

      if (oldVal === false && val === true) {
        this.$nextTick(function () {
          _this.$refs.readOnly.className = _this.readOnlyClass;
        });
      }
    }
  },

  mounted: function mounted() {
    var _this2 = this;

    // Check default value from parent v-model.
    if (this.value) {
      this.processValue(this.formatToNumber(this.value));
      this.formatValue(this.value);
    }

    // Set read-only span element's class
    if (this.readOnly) {
      this.$refs.readOnly.className = this.readOnlyClass;
    }

    // In case of delayed v-model new value.
    setTimeout(function () {
      _this2.processValue(_this2.formatToNumber(_this2.value));
      _this2.formatValue(_this2.value);
    }, 500);
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 51 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_TopBar_vue__ = __webpack_require__(145);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_TopBar_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_TopBar_vue__);




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'app',
  data: function data() {
    return {
      title: 'NeeV',
      target: '/',
      mode: 'router',
      mainMenu: [{
        title: 'NeeV',
        target: '/',
        mode: 'router',
        class: 'logo'
      }, {
        title: 'Building Blocks',
        target: '#',
        mode: 'link',
        submenu: [{
          title: 'Post Footer',
          target: '/blog-post-footer',
          mode: 'router'
        }, {
          title: 'Product Card',
          target: '/product-card',
          mode: 'router'
        }]
      }, {
        title: 'Components',
        target: '/components',
        mode: 'router',
        submenu: [{
          title: 'Accordion',
          target: '/components/accordion',
          mode: 'router'
        }, {
          title: 'Accordion Menu',
          target: '/components/accordion-menu',
          mode: 'router'
        }, {
          title: 'Breadcrumbs',
          target: '/components/breadcrumbs',
          mode: 'router'
        }, {
          title: 'Drilldown Menu',
          target: '/components/drilldown-menu',
          mode: 'router'
        }, {
          title: 'Dropdown',
          target: '/components/dropdown',
          mode: 'router'
        }, {
          title: 'Dropdown Menu',
          target: '/components/dropdown-menu',
          mode: 'router'
        }, {
          title: 'Home Component',
          target: '/components/home',
          mode: 'router'
        }, {
          title: 'Magellan',
          target: '/components/magellan',
          mode: 'router'
        }, {
          title: 'Orbit',
          target: '/components/orbit',
          mode: 'router'
        }, {
          title: 'Pagination',
          target: '/components/pagination',
          mode: 'router'
        }, {
          title: 'Reveal',
          target: '/components/reveal',
          mode: 'router'
        }, {
          title: 'Slider',
          target: '/components/slider',
          mode: 'router'
        }, {
          title: 'Tabs',
          target: '/components/tabs',
          mode: 'router'
        }, {
          title: 'Tooltip',
          target: '/components/tooltip',
          mode: 'router'
        }]
      }]
    };
  },

  components: {
    TopBar: __WEBPACK_IMPORTED_MODULE_0__components_core_TopBar_vue___default.a
  },
  mounted: function mounted() {
    this.offCanvas = new Foundation.OffCanvas($('#offCanvas'));
    this.dropdownMenu = new Foundation.DropdownMenu($('#mainDropDown'));
  }
});

/***/ }),
/* 52 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'blog-post-footer',
  mounted: function mounted() {},
  data: function data() {
    return {
      author: 'Product Card',
      bio: 'Bill Murray is an American actor, comedian, and writer.'
    };
  },
  destroyed: function destroyed() {}
});

/***/ }),
/* 53 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'product-card',
  mounted: function mounted() {},
  data: function data() {
    return {
      msg: 'Product Card'
    };
  },
  destroyed: function destroyed() {}
});

/***/ }),
/* 54 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Accordion_AccordionTab_vue__ = __webpack_require__(137);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Accordion_AccordionTab_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__Accordion_AccordionTab_vue__);




var accordionSettings = ['slideSpeed', 'multiExpand', 'allowAllClosed', 'deepLink', 'deepLinkSmudge', 'deepLinkSmudgeDelay', 'updateHistory'];

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion',
  mounted: function mounted() {
    this.accordion = new Foundation.Accordion($('#' + this.id), this.props);
  },

  computed: {
    props: function props() {
      var newSettings = {};
      for (var i = 0; i < accordionSettings.length; i++) {
        newSettings[accordionSettings[i]] = this.$props[accordionSettings[i]];
      }
      return newSettings;
    }
  },
  watch: {
    props: function props(val) {
      this.accordion = new Foundation.Accordion($('#' + this.id), this.props);
    }
  },
  components: {
    AccordionTab: __WEBPACK_IMPORTED_MODULE_0__Accordion_AccordionTab_vue___default.a
  },
  data: function data() {
    return {
      msg: 'Accordion'
    };
  },

  props: {
    id: {
      type: String,
      default: function _default() {
        return 'accordion';
      }
    },

    slideSpeed: {
      type: Number,
      default: function _default() {
        return 250;
      }
    },
    multiExpand: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    allowAllClosed: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    deepLink: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    deepLinkSmudge: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    deepLinkSmudgeDelay: {
      type: Number,
      default: function _default() {
        return 300;
      }
    },
    updateHistory: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },

    panels: {
      type: Array,
      default: function _default() {
        return [{
          title: 'Accordion 1',
          content: 'If you init Foundation in the component, this will work fine.'
        }, {
          title: 'Accordion 2',
          content: 'I need to be clicked, in order to show up.'
        }];
      }
    }
  },
  destroyed: function destroyed() {
    this.accordion.destroy();
  }
});

/***/ }),
/* 55 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion-tab',
  data: function data() {
    return {
      dL: this.deepLink ? this.deepLink : false,
      tabIndex: this.index ? this.index : 0
    };
  },

  props: {
    index: {
      type: Number,
      default: function _default() {
        return 0;
      }
    },
    panel: {
      type: Object,
      default: function _default() {}
    },
    deepLink: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    }
  }
});

/***/ }),
/* 56 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_helpers_StandardMenu_vue__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_helpers_StandardMenu_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_helpers_StandardMenu_vue__);




var accordionMenuSettings = ['slideSpeed', 'multiOpen', 'subMenuToggle', 'subMenuToggleText'];
var i = 0;

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion-menu',
  mounted: function mounted() {
    this.accordionMenu = new Foundation.AccordionMenu($('#' + this.id), this.props);
  },

  components: {
    StandardMenu: __WEBPACK_IMPORTED_MODULE_0__components_helpers_StandardMenu_vue___default.a
  },
  computed: {
    props: function props() {
      var newSettings = {};
      for (i = 0; i < accordionMenuSettings.length; i++) {
        newSettings[accordionMenuSettings[i]] = this.$props[accordionMenuSettings[i]];
      }
      return newSettings;
    }
  },
  watch: {
    props: function props(val) {
      this.accordionMenu.destroy();
      this.accordionMenu = new Foundation.AccordionMenu($('#' + this.id), this.props);
      if (this.$props.submenuToggle === false) {
        var parent = document.getElementById(this.id);
        var children = document.getElementsByClassName('submenu-toggle');
        for (i = 0; i < children.length; i++) {
          parent.removeChild(children[i]);
        }
      }
      console.log('Done');
    }
  },
  data: function data() {
    return {
      msg: 'Accordion Menu'
    };
  },

  props: {
    id: {
      type: String,
      default: function _default() {
        return 'accordion-menu';
      }
    },
    menu: {
      type: Array,
      default: function _default() {
        return [{
          title: 'Home',
          target: '/'
        }];
      }
    },
    slideSpeed: {
      type: Number,
      default: function _default() {
        return 250;
      }
    },
    multiOpen: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    submenuToggle: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    submenuToggleText: {
      type: String,
      default: function _default() {
        return 'Back';
      }
    },
    mode: {
      type: String,
      default: function _default() {
        return 'router';
      }
    }
  },
  destroyed: function destroyed() {
    this.accordionMenu.destroy();
  }
});

/***/ }),
/* 57 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'breadcrumbs',
  data: function data() {
    return {};
  }
});

/***/ }),
/* 58 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'drilldown',
  mounted: function mounted() {
    this.drilldown = new Foundation.Drilldown($('#drilldown'), {
      animationDuration: 500
    });
  },
  data: function data() {
    return {
      msg: 'Drilldown Menu',
      menuStructure: this.menu ? this.menu : [],
      menuMode: this.mode ? this.mode : 'router'
    };
  },

  props: {
    menu: {
      type: Array,
      default: function _default() {
        return [{
          title: 'Home',
          target: '/'
        }];
      }
    },
    mode: {
      type: String,
      default: function _default() {
        return 'router';
      }
    }
  },
  destroyed: function destroyed() {
    this.drilldown.destroy();
  }
});

/***/ }),
/* 59 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


var dropdownSettings = ['parentClass', 'hoverDelay', 'hover', 'hoverPane', 'vOffset', 'hOffset', 'positionClass', 'position', 'alignment', 'allowOverlap', 'allowBottomOverlap', 'trapFocus', 'autoFocus', 'closeOnClick'];
var i = 0;

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'dropdown',
  props: {
    buttonText: {
      type: String,
      default: function _default() {
        return 'Toggle Dropdown';
      }
    },
    id: {
      type: String,
      default: function _default() {
        return 'dropdown';
      }
    },
    content: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    parentClass: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    hoverDelay: {
      type: Number,
      default: function _default() {
        return 250;
      }
    },
    hover: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    hoverPane: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    vOffset: {
      type: String,
      default: function _default() {
        return '0';
      }
    },
    hOffset: {
      type: String,
      default: function _default() {
        return '0';
      }
    },
    positionClass: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    position: {
      type: String,
      default: function _default() {
        return 'auto';
      }
    },
    alignment: {
      type: String,
      default: function _default() {
        return 'auto';
      }
    },
    allowOverlap: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    allowBottomOverlap: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    trapFocus: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    autoFocus: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    closeOnClick: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    }
  },
  computed: {
    props: function props() {
      var newSettings = {};
      for (i = 0; i < dropdownSettings.length; i++) {
        newSettings[dropdownSettings[i]] = this.$props[dropdownSettings[i]];
      }
      return newSettings;
    }
  },
  watch: {
    props: function props(val) {
      $('#' + this.id).foundation('_destroy');
      this.dropdown.destroy();
      this.dropdown = new Foundation.Dropdown($('#' + this.id), this.props);
    }
  },
  mounted: function mounted() {
    this.dropdown = new Foundation.Dropdown($('#' + this.id), this.props);
  },
  destroyed: function destroyed() {
    this.dropdown.destroy();
  }
});

/***/ }),
/* 60 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'dropdown-menu',
  mounted: function mounted() {
    this.dropdownMenu = new Foundation.DropdownMenu($('#dropdown-menu'), {
      hoverDelay: 300
    });
  },
  data: function data() {
    return {
      menuMode: this.mode ? this.mode : 'links',
      menuStructure: this.menu ? this.menu : []
    };
  },

  props: {
    mode: {
      type: String,
      default: function _default() {
        return 'router';
      }
    },
    menu: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  },
  destroyed: function destroyed() {
    this.dropdownMenu.destroy();
  }
});

/***/ }),
/* 61 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'hello',
  data: function data() {
    return {
      msg: 'Welcome to Your Vue.js App'
    };
  }
});

/***/ }),
/* 62 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'hello',
  data: function data() {
    return {
      msg: 'Vue + Foundation'
    };
  }
});

/***/ }),
/* 63 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'magellan',
  mounted: function mounted() {
    this.magellan = new Foundation.Magellan($('#magellan'), {
      animationEasing: 'swing'
    });
  },
  data: function data() {
    return {
      msg: 'Magellan'
    };
  },
  destroyed: function destroyed() {
    this.magellan.destroy();
  }
});

/***/ }),
/* 64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Orbit_OrbitArrow_vue__ = __webpack_require__(140);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Orbit_OrbitArrow_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__Orbit_OrbitArrow_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Orbit_OrbitBullets_vue__ = __webpack_require__(141);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Orbit_OrbitBullets_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__Orbit_OrbitBullets_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Orbit_OrbitSlide_vue__ = __webpack_require__(142);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Orbit_OrbitSlide_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__Orbit_OrbitSlide_vue__);






var orbitSettings = ['timerDelay', 'bullets', 'navButtons', 'autoPlay', 'infiniteWrap', 'accessible', 'pauseOnHover', 'swipe', 'containerClass', 'slideClass', 'boxOfBullets', 'prevClass', 'nextClass', 'useMUI', 'animInFromRight', 'animOutToRight', 'animInFromLeft', 'animOutToLeft'];

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orbit',
  mounted: function mounted() {
    this.orbit = new Foundation.Orbit($('#' + this.id), this.props);
  },

  computed: {
    props: function props() {
      var newSettings = {};
      for (var i = 0; i < orbitSettings.length; i++) {
        newSettings[orbitSettings[i]] = this.$props[orbitSettings[i]];
      }
      return newSettings;
    }
  },
  watch: {
    props: function props(val) {
      $('#' + this.id).foundation('_reset');
      this.orbit = new Foundation.Orbit($('#' + this.id), this.props);
    }
  },
  components: {
    OrbitArrow: __WEBPACK_IMPORTED_MODULE_0__Orbit_OrbitArrow_vue___default.a,
    OrbitBullets: __WEBPACK_IMPORTED_MODULE_1__Orbit_OrbitBullets_vue___default.a,
    OrbitSlide: __WEBPACK_IMPORTED_MODULE_2__Orbit_OrbitSlide_vue___default.a
  },
  data: function data() {
    return {
      label: this.title ? this.title : '',
      images: this.slides ? this.slides : ''
    };
  },

  props: {
    title: {
      type: String,
      default: function _default() {
        return 'Orbit';
      }
    },
    id: {
      type: String,
      default: function _default() {
        return 'orbit';
      }
    },
    containerClass: {
      type: String,
      default: function _default() {
        return 'orbit-container';
      }
    },
    slideClass: {
      type: String,
      default: function _default() {
        return 'orbit-slide';
      }
    },
    boxOfBullets: {
      type: String,
      default: function _default() {
        return 'orbit-bullets';
      }
    },
    prevClass: {
      type: String,
      default: function _default() {
        return 'orbit-previous';
      }
    },
    nextClass: {
      type: String,
      default: function _default() {
        return 'orbit-next';
      }
    },
    animInFromRight: {
      type: String,
      default: function _default() {
        return 'slide-in-right';
      }
    },
    animOutToRight: {
      type: String,
      default: function _default() {
        return 'slide-out-right';
      }
    },
    animInFromLeft: {
      type: String,
      default: function _default() {
        return 'slide-in-left';
      }
    },
    animOutToLeft: {
      type: String,
      default: function _default() {
        return 'slide-out-left';
      }
    },
    geoSync: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    accessible: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    useMUI: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    pauseOnHover: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    swipe: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    bullets: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    autoPlay: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    infiniteWrap: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    navButtons: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    slides: {
      type: Array,
      default: function _default() {
        return [{
          url: __webpack_require__(23),
          title: 'Space, the final frontier.',
          alt: 'Space'
        }, {
          url: __webpack_require__(24),
          title: 'Lets Rocket!',
          alt: 'Space'
        }, {
          url: __webpack_require__(25),
          title: 'Encapsulating',
          alt: 'Space'
        }, {
          url: __webpack_require__(26),
          title: 'Outta This World',
          alt: 'Space'
        }];
      }
    },
    timerDelay: {
      type: Number,
      default: function _default() {
        return 3000;
      }
    }
  },
  destroyed: function destroyed() {
    this.orbit.destroy();
  }
});

/***/ }),
/* 65 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orbit-arrow',
  props: {
    direction: {
      type: String,
      default: function _default() {
        return 'prev';
      }
    }
  }
});

/***/ }),
/* 66 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orbit-bullets',
  props: {
    images: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  }
});

/***/ }),
/* 67 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orbit-slide',
  props: {
    image: {
      type: Object,
      default: function _default() {}
    }
  }
});

/***/ }),
/* 68 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'pagination',
  data: function data() {
    return {};
  }
});

/***/ }),
/* 69 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Reveal_RevealContent_vue__ = __webpack_require__(143);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Reveal_RevealContent_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__Reveal_RevealContent_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Reveal_RevealTrigger_vue__ = __webpack_require__(144);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Reveal_RevealTrigger_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__Reveal_RevealTrigger_vue__);





var i = 0;

var revealSettings = ['closeButton', 'animationIn', 'animationOut', 'showDelay', 'hideDelay', 'closeOnClick', 'closeOnEsc', 'multipleOpened', 'vOffset', 'hOffset', 'fullScreen', 'bottomOffsetPct', 'overlay', 'resetOnClose', 'deepLink', 'updateHistory', 'appendTo', 'additionalOverlayClasses'];

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'reveal',
  mounted: function mounted() {
    this.reveal = new Foundation.Reveal($('#' + this.id), this.props);
  },

  components: {
    RevealContent: __WEBPACK_IMPORTED_MODULE_0__Reveal_RevealContent_vue___default.a,
    RevealTrigger: __WEBPACK_IMPORTED_MODULE_1__Reveal_RevealTrigger_vue___default.a
  },
  computed: {
    props: function props() {
      var newSettings = {};
      for (i = 0; i < revealSettings.length; i++) {
        newSettings[revealSettings[i]] = this.$props[revealSettings[i]];
      }
      return newSettings;
    }
  },
  data: function data() {
    return {
      msg: 'Reveal'
    };
  },

  watch: {
    props: function props(val) {
      this.reveal.destroy();
      this.reveal = new Foundation.Reveal($('#' + this.id), this.props);
    }
  },
  props: {
    id: {
      type: String,
      default: function _default() {
        return 'reveal-dialog';
      }
    },
    closeButton: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    animationIn: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    animationOut: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    showDelay: {
      type: Number,
      default: function _default() {
        return 0;
      }
    },
    hideDelay: {
      type: Number,
      default: function _default() {
        return 0;
      }
    },
    closeOnClick: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    closeOnEsc: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    multipleOpened: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    vOffset: {
      type: String,
      default: function _default() {
        return 'auto';
      }
    },
    hOffset: {
      type: String,
      default: function _default() {
        return 'auto';
      }
    },
    fullScreen: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    btmOffsetPct: {
      type: Number,
      default: function _default() {
        return 10;
      }
    },
    overlay: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    resetOnClose: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    deepLink: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    updateHistory: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    appendTo: {
      type: String,
      default: function _default() {
        return 'body';
      }
    },
    additionalOverlayClasses: {
      type: String,
      default: function _default() {
        return '';
      }
    }
  },
  destroyed: function destroyed() {
    this.reveal.destroy();
  }
});

/***/ }),
/* 70 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'reveal-trigger',
  props: {
    id: {
      type: String,
      default: function _default() {
        return 'reveal-dialog';
      }
    },
    text: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    closeButton: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    }
  }
});

/***/ }),
/* 71 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'reveal-trigger',
  data: function data() {
    return {
      revealId: this.id ? this.id : 'reveal-dialog',
      buttonText: this.text ? this.text : 'Open Modal'
    };
  },

  props: {
    id: {
      type: String,
      default: function _default() {
        return 'reveal-dialog';
      }
    },
    text: {
      type: String,
      default: function _default() {
        return 'Open Modal';
      }
    }
  }
});

/***/ }),
/* 72 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'slider',
  mounted: function mounted() {
    var _this = this;

    this.slider = new Foundation.Slider($('#' + this.sliderID), {});
    this.slider.$element.on('moved.zf.slider', function () {
      _this.dataValue = _this.slider.inputs.val();
    });
  },
  data: function data() {
    return {
      msg: 'Slider',
      dataValue: this.currentValue ? this.currentValue : 0,
      dataEnd: this.max ? this.max : 100,
      isVertical: this.verticalLayout ? this.verticalLayout : false,
      isDisabled: this.disabled ? this.disabled : false,
      stepValue: this.stepSize ? this.stepSize : 5,
      sliderID: this.sliderId ? this.sliderId : 'slider'
    };
  },

  props: {
    currentValue: {
      type: Number,
      default: function _default() {
        return 60;
      }
    },
    max: {
      type: Number,
      default: function _default() {
        return 100;
      }
    },
    verticalLayout: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    disabled: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    stepSize: {
      type: Number,
      default: function _default() {
        return 10;
      }
    },
    sliderId: {
      type: String,
      default: function _default() {
        return 'slider';
      }
    }
  },
  destroyed: function destroyed() {
    this.slider.destroy();
  }
});

/***/ }),
/* 73 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


var tabSettings = ['deepLink', 'deepLinkSmudge', 'deepLinkSmudgeDelay', 'updateHistory', 'autoFocus', 'wrapOnKeys', 'matchHeight', 'activeCollapse', 'linkClass', 'linkActiveClass', 'panelClass', 'panelActiveClass'];

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'tabs',
  mounted: function mounted() {
    this.tabs = new Foundation.Tabs($('#' + this.id), this.props);
  },

  computed: {
    props: function props() {
      var newSettings = {};
      for (var i = 0; i < tabSettings.length; i++) {
        newSettings[tabSettings[i]] = this.$props[tabSettings[i]];
      }
      return newSettings;
    }
  },
  watch: {
    props: function props(val) {
      this.tabs = new Foundation.Tabs($('#' + this.id), this.props);
    }
  },
  data: function data() {
    return {
      msg: 'Tabs'
    };
  },

  props: {
    id: {
      type: String,
      default: function _default() {
        return 'tabs';
      }
    },
    expandTabs: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    deepLink: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    deepLinkSmudge: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    deepLinkSmudgeDelay: {
      type: Number,
      default: function _default() {
        return 300;
      }
    },
    updateHistory: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    autoFocus: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    wrapOnKeys: {
      type: Boolean,
      default: function _default() {
        return true;
      }
    },
    matchHeight: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    activeCollapse: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    linkClass: {
      type: String,
      default: function _default() {
        return 'tabs-title';
      }
    },
    linkActiveClass: {
      type: String,
      default: function _default() {
        return 'is-active';
      }
    },
    panelClass: {
      type: String,
      default: function _default() {
        return 'tabs-panel';
      }
    },
    panelActiveClass: {
      type: String,
      default: function _default() {
        return 'is-active';
      }
    },
    panels: {
      type: Array,
      default: []
    }
  },
  destroyed: function destroyed() {
    this.tabs.destroy();
  }
});

/***/ }),
/* 74 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'toggle-switch',
  watch: {
    value: function value(val) {
      this.$emit('input', val);
    },
    checked: function checked(val) {
      this.value = val;
    }
  },
  data: function data() {
    return {
      switchId: this.id ? this.id : 'toggleSwitch',
      switchSize: this.size ? this.size : '',
      switchMode: this.mode ? this.mode : '',
      switchName: this.name ? this.name : '',
      activeLabel: this.activeText ? this.activeText : 'Yes',
      inactiveLabel: this.inactiveText ? this.inactiveText : 'No',
      default: '',
      switchClass: '',
      value: null
    };
  },

  methods: {
    onChange: function onChange(event) {
      this.$emit('input', event.target.checked);
    }
  },
  beforeMount: function beforeMount() {
    this.value = this.checked;
  },
  mounted: function mounted() {
    this.$emit('input', this.value);
  },

  props: {
    id: {
      type: String,
      default: function _default() {
        return 'toggleSwitch';
      }
    },
    checked: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    size: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    mode: {
      type: String,
      default: function _default() {
        return 'checkbox';
      }
    },
    name: {
      type: String,
      default: function _default() {
        return 'toggleSwitch';
      }
    },
    activeText: {
      type: String,
      default: function _default() {
        return 'Yes';
      }
    },
    inactiveText: {
      type: String,
      default: function _default() {
        return 'No';
      }
    }
  }
});

/***/ }),
/* 75 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'tooltip',
  mounted: function mounted() {
    this.tooltip = $('.has-tip').foundation();
  },
  data: function data() {
    return {
      msg: 'Tooltip'
    };
  },
  destroyed: function destroyed() {}
});

/***/ }),
/* 76 */
/***/ (function(module, exports) {



module.exports = {
  name: 'top-bar',
  data: function data() {
    return {
      menuTitle: this.title ? this.title : '',
      menuMode: this.mode ? this.mode : 'links',
      left: [],
      right: []
    };
  },
  mounted: function mounted() {
    this.dropdownMenu = new Foundation.DropdownMenu($('#main-dropdown-menu'), {
      hoverDelay: 300
    });
  },
  destroyed: function destroyed() {
    this.dropdownMenu.destroy();
  },

  props: {
    title: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    mode: {
      type: String,
      default: function _default() {
        return 'router';
      }
    },
    leftMenu: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    rightMenu: {
      type: Array,
      default: function _default() {
        return [];
      }
    }
  }
};

/***/ }),
/* 77 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });


/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      verticalLayout: this.vertical ? this.vertical : false,
      linkAlignment: this.alignment ? this.alignment : '',
      menuStructure: this.menu ? this.menu : [],
      menuMode: this.mode ? this.mode : 'links',
      expandMenu: this.expanded ? this.expanded : false
    };
  },

  props: {
    menu: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    vertical: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    },
    type: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    mode: {
      type: String,
      default: function _default() {
        return 'router';
      }
    },
    links: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    alignment: {
      type: String,
      default: function _default() {
        return '';
      }
    },
    expanded: {
      type: Boolean,
      default: function _default() {
        return false;
      }
    }
  }
});

/***/ }),
/* 78 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_AccordionMenu_vue__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_AccordionMenu_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_AccordionMenu_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);




/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion-menu-page',
  components: {
    AccordionMenu: __WEBPACK_IMPORTED_MODULE_0__components_core_AccordionMenu_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a
  },
  data: function data() {
    return {
      title: 'Accordion Menu',
      menu: [{
        title: 'Zurb Vue',
        target: '/',
        mode: 'router',
        class: 'logo'
      }, {
        title: 'Building Blocks',
        target: '#',
        mode: 'link',
        submenu: [{
          title: 'Post Footer',
          target: '/blog-post-footer',
          mode: 'router'
        }, {
          title: 'Product Card',
          target: '/product-card',
          mode: 'router'
        }]
      }, {
        title: 'Components',
        target: '#',
        mode: 'router',
        submenu: [{
          title: 'Accordion',
          target: '/components/accordion',
          mode: 'router'
        }, {
          title: 'Accordion Menu',
          target: '/components/accordion-menu',
          mode: 'router'
        }, {
          title: 'Breadcrumbs',
          target: '/components/breadcrumbs',
          mode: 'router'
        }, {
          title: 'Drilldown Menu',
          target: '/components/drilldown-menu',
          mode: 'router'
        }, {
          title: 'Dropdown',
          target: '/components/dropdown',
          mode: 'router'
        }, {
          title: 'Dropdown Menu',
          target: '/components/dropdown-menu',
          mode: 'router'
        }, {
          title: 'Home Component',
          target: '/components/home',
          mode: 'router'
        }, {
          title: 'Magellan',
          target: '/components/magellan',
          mode: 'router'
        }, {
          title: 'Orbit',
          target: '/components/orbit',
          mode: 'router'
        }, {
          title: 'Pagination',
          target: '/components/pagination',
          mode: 'router'
        }, {
          title: 'Reveal',
          target: '/components/reveal',
          mode: 'router'
        }, {
          title: 'Slider',
          target: '/components/slider',
          mode: 'router'
        }, {
          title: 'Tabs',
          target: '/components/tabs',
          mode: 'router'
        }, {
          title: 'Tooltip',
          target: '/components/tooltip',
          mode: 'router'
        }]
      }],
      multiOpen: true,
      submenuToggle: false,
      submenuToggleText: 'NeeV',
      slideSpeed: 250
    };
  }
});

/***/ }),
/* 79 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion_vue__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Accordion_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue_numeric__);





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion-page',
  components: {
    Accordion: __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a,
    VueNumeric: __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default.a
  },
  data: function data() {
    return {
      title: 'Accordion',
      slideSpeed: 250,
      multiExpand: false,
      allowAllClosed: false,
      deepLink: true,
      deepLinkSmudge: false,
      deepLinkSmudgeDelay: 300,
      updateHistory: false,
      panels: [{
        title: 'Accordion 1',
        content: 'If you init Foundation in the component, this will work fine.'
      }, {
        title: 'Accordion 2',
        content: 'I need to be clicked, in order to show up.'
      }]
    };
  },
  mounted: function mounted() {
    this.equalizer = new Foundation.Equalizer($('.debug-row'), {
      equalizeByRow: true
    });
    $(document).resize(function () {
      var heights;
      $('.debug-row').foundation('getHeights', heights);
      $('.debug-row').foundation('applyHeight', heights);
    });
  },
  destroyed: function destroyed() {
    this.equalizer.destroy();
  }
});

/***/ }),
/* 80 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Accordion__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_AccordionMenu__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_AccordionMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_AccordionMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_core_Breadcrumbs__ = __webpack_require__(29);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__components_core_Breadcrumbs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__components_core_Breadcrumbs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_core_DrilldownMenu__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_core_DrilldownMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3__components_core_DrilldownMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_core_Dropdown__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_core_Dropdown___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4__components_core_Dropdown__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_core_DropdownMenu__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_core_DropdownMenu___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5__components_core_DropdownMenu__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_core_Magellan__ = __webpack_require__(33);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_core_Magellan___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6__components_core_Magellan__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_core_Orbit__ = __webpack_require__(34);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_core_Orbit___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_7__components_core_Orbit__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8__components_core_Pagination__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_core_Reveal__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_core_Reveal___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_9__components_core_Reveal__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_core_Slider__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__components_core_Slider___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_10__components_core_Slider__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_core_ToggleSwitch__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_core_ToggleSwitch___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11__components_core_ToggleSwitch__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_core_Tabs__ = __webpack_require__(38);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__components_core_Tabs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_12__components_core_Tabs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__components_core_Tooltip__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__components_core_Tooltip___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_13__components_core_Tooltip__);
















/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'components-page',
  data: function data() {
    return {
      mainMenu: [{
        title: 'Zurb Vue',
        target: '/',
        mode: 'router',
        class: 'logo'
      }, {
        title: 'Building Blocks',
        target: '#',
        mode: 'link',
        submenu: [{
          title: 'Post Footer',
          target: '/blog-post-footer',
          mode: 'router'
        }, {
          title: 'Product Card',
          target: '/product-card',
          mode: 'router'
        }]
      }, {
        title: 'Components',
        target: '/components',
        mode: 'router',
        submenu: [{
          title: 'Accordion',
          target: '/components/accordion',
          mode: 'router'
        }, {
          title: 'Accordion Menu',
          target: '/components/accordion-menu',
          mode: 'router'
        }, {
          title: 'Breadcrumbs',
          target: '/components/breadcrumbs',
          mode: 'router'
        }, {
          title: 'Drilldown Menu',
          target: '/components/drilldown-menu',
          mode: 'router'
        }, {
          title: 'Dropdown',
          target: '/components/dropdown',
          mode: 'router'
        }, {
          title: 'Dropdown Menu',
          target: '/components/dropdown-menu',
          mode: 'router'
        }, {
          title: 'Home Component',
          target: '/components/home',
          mode: 'router'
        }, {
          title: 'Magellan',
          target: '/components/magellan',
          mode: 'router'
        }, {
          title: 'Orbit',
          target: '/components/orbit',
          mode: 'router'
        }, {
          title: 'Pagination',
          target: '/components/pagination',
          mode: 'router'
        }, {
          title: 'Reveal',
          target: '/components/reveal',
          mode: 'router'
        }, {
          title: 'Slider',
          target: '/components/slider',
          mode: 'router'
        }, {
          title: 'Tabs',
          target: '/components/tabs',
          mode: 'router'
        }, {
          title: 'Tooltip',
          target: '/components/tooltip',
          mode: 'router'
        }]
      }]

    };
  },

  components: {
    Accordion: __WEBPACK_IMPORTED_MODULE_0__components_core_Accordion___default.a,
    AccordionMenu: __WEBPACK_IMPORTED_MODULE_1__components_core_AccordionMenu___default.a,
    Breadcrumbs: __WEBPACK_IMPORTED_MODULE_2__components_core_Breadcrumbs___default.a,
    DrilldownMenu: __WEBPACK_IMPORTED_MODULE_3__components_core_DrilldownMenu___default.a,
    Dropdown: __WEBPACK_IMPORTED_MODULE_4__components_core_Dropdown___default.a,
    DropdownMenu: __WEBPACK_IMPORTED_MODULE_5__components_core_DropdownMenu___default.a,
    Magellan: __WEBPACK_IMPORTED_MODULE_6__components_core_Magellan___default.a,
    Orbit: __WEBPACK_IMPORTED_MODULE_7__components_core_Orbit___default.a,
    Pagination: __WEBPACK_IMPORTED_MODULE_8__components_core_Pagination___default.a,
    Reveal: __WEBPACK_IMPORTED_MODULE_9__components_core_Reveal___default.a,
    Slider: __WEBPACK_IMPORTED_MODULE_10__components_core_Slider___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_11__components_core_ToggleSwitch___default.a,
    Tabs: __WEBPACK_IMPORTED_MODULE_12__components_core_Tabs___default.a,
    Tooltip: __WEBPACK_IMPORTED_MODULE_13__components_core_Tooltip___default.a
  }
});

/***/ }),
/* 81 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Dropdown_vue__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Dropdown_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Dropdown_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'dropdown-page',
  components: {
    Dropdown: __WEBPACK_IMPORTED_MODULE_0__components_core_Dropdown_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a
  },
  data: function data() {
    return {
      title: 'Dropdown',
      id: 'dropdown',
      parentClass: '',
      hoverDelay: 250,
      hover: false,
      hoverPane: false,
      vOffset: '0',
      hOffset: '0',
      positionClass: '',
      position: 'auto',
      alignment: 'auto',
      allowOverlap: false,
      allowBottomOverlap: true,
      trapFocus: false,
      autoFocus: false,
      closeOnClick: false,
      buttonText: 'Toggle Dropdown',
      content: '<p>Just some sample content to fill a dropdown</p><p>Another paragraph.</p>'
    };
  },
  mounted: function mounted() {
    this.equalizer = new Foundation.Equalizer($('.debug-row'), {
      equalizeByRow: true
    });
    $(document).resize(function () {
      var heights;
      $('.debug-row').foundation('getHeights', heights);
      $('.debug-row').foundation('applyHeight', heights);
    });
  },
  destroyed: function destroyed() {
    this.equalizer.destroy();
  }
});

/***/ }),
/* 82 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Orbit_vue__ = __webpack_require__(34);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Orbit_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Orbit_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue_numeric__);






/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'orbit-page',
  components: {
    Orbit: __WEBPACK_IMPORTED_MODULE_0__components_core_Orbit_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a,
    VueNumeric: __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default.a
  },
  data: function data() {
    return {
      title: 'Orbit',
      id: 'orbit',
      containerClass: 'orbit-container',
      slideClass: 'orbit-slide',
      boxOfBullets: 'orbit-bullets',
      prevClass: 'orbit-previous',
      nextClass: 'orbit-next',
      animInFromRight: 'slide-in-right',
      animOutToRight: 'slide-out-right',
      animInFromLeft: 'slide-in-left',
      animOutToLeft: 'slide-out-left',
      geoSync: '',
      accessible: true,
      useMUI: true,
      pauseOnHover: true,
      swipe: true,
      bullets: true,
      autoPlay: true,
      infiniteWrap: true,
      navButtons: true,
      slides: [{
        url: __webpack_require__(23),
        title: 'Space, the final frontier.',
        alt: 'Space'
      }, {
        url: __webpack_require__(24),
        title: 'Lets Rocket!',
        alt: 'Space'
      }, {
        url: __webpack_require__(25),
        title: 'Encapsulating',
        alt: 'Space'
      }, {
        url: __webpack_require__(26),
        title: 'Outta This World',
        alt: 'Space'
      }],
      timerDelay: 500
    };
  },
  mounted: function mounted() {
    this.equalizer = new Foundation.Equalizer($('.debug-row'), {
      equalizeByRow: true
    });
    $(document).resize(function () {
      var heights;
      $('.debug-row').foundation('getHeights', heights);
      $('.debug-row').foundation('applyHeight', heights);
    });
  },
  destroyed: function destroyed() {
    this.equalizer.destroy();
  }
});

/***/ }),
/* 83 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Reveal_vue__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Reveal_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Reveal_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'reveal-page',
  components: {
    Reveal: __WEBPACK_IMPORTED_MODULE_0__components_core_Reveal_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a
  },
  data: function data() {
    return {
      title: 'Reveal',
      id: 'reveal',
      closeButton: true,
      animationIn: '',
      animationOut: '',
      showDelay: 0,
      hideDelay: 0,
      closeOnClick: true,
      closeOnEsc: true,
      multipleOpened: false,
      vOffset: 'auto',
      hOffset: 'auto',
      fullScreen: false,
      bottomOffsetPct: 10,
      overlay: true,
      resetOnClose: false,
      deepLink: false,
      updateHistory: false,
      appendTo: 'body',
      additionalOverlayClasses: '',
      panels: [{
        title: 'Tab 1',
        content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
      }, {
        title: 'Tab 2',
        content: 'Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus.'
      }, {
        title: 'Tab 3',
        content: 'Curabitur sit amet dolor vitae justo vulputate semper in quis ipsum. Proin dignissim, eros vitae aliquet pellentesque, tortor odio molestie felis, in tempor lectus metus nec lacus.'
      }]
    };
  },
  mounted: function mounted() {
    this.equalizer = new Foundation.Equalizer($('.debug-row'), {
      equalizeByRow: true
    });
    $(document).resize(function () {
      var heights;
      $('.debug-row').foundation('getHeights', heights);
      $('.debug-row').foundation('applyHeight', heights);
    });
  },
  destroyed: function destroyed() {
    this.equalizer.destroy();
  }
});

/***/ }),
/* 84 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Tabs_vue__ = __webpack_require__(38);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_core_Tabs_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__components_core_Tabs_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric__ = __webpack_require__(14);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_vue_numeric__);





/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'accordion-page',
  components: {
    Tabs: __WEBPACK_IMPORTED_MODULE_0__components_core_Tabs_vue___default.a,
    ToggleSwitch: __WEBPACK_IMPORTED_MODULE_1__components_core_ToggleSwitch_vue___default.a,
    VueNumeric: __WEBPACK_IMPORTED_MODULE_2_vue_numeric___default.a
  },
  data: function data() {
    return {
      title: 'Tabs',
      id: 'tabs',
      deepLink: true,
      deepLinkSmudge: false,
      deepLinkSmudgeDelay: 300,
      updateHistory: false,
      autoFocus: false,
      wrapOnKeys: true,
      expandTabs: false,
      matchHeight: false,
      activeCollapse: false,
      linkClass: 'tabs-title',
      linkActiveClass: 'is-active',
      panelClass: 'tabs-panel',
      panelActiveClass: 'is-active',
      panels: [{
        title: 'Tab 1',
        content: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'
      }, {
        title: 'Tab 2',
        content: 'Vivamus hendrerit arcu sed erat molestie vehicula. Sed auctor neque eu tellus rhoncus ut eleifend nibh porttitor. Ut in nulla enim. Phasellus molestie magna non est bibendum non venenatis nisl tempor. Suspendisse dictum feugiat nisl ut dapibus.'
      }, {
        title: 'Tab 3',
        content: 'Curabitur sit amet dolor vitae justo vulputate semper in quis ipsum. Proin dignissim, eros vitae aliquet pellentesque, tortor odio molestie felis, in tempor lectus metus nec lacus.'
      }]
    };
  },
  mounted: function mounted() {
    this.equalizer = new Foundation.Equalizer($('.debug-row'), {
      equalizeByRow: true
    });
    $(document).resize(function () {
      var heights;
      $('.debug-row').foundation('getHeights', heights);
      $('.debug-row').foundation('applyHeight', heights);
    });
  },
  destroyed: function destroyed() {
    this.equalizer.destroy();
  }
});

/***/ }),
/* 85 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_jquery__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_jquery___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_jquery__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_vue__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__App__ = __webpack_require__(46);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__App___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__App__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__router__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__store__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_vuex_router_sync__ = __webpack_require__(47);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5_vuex_router_sync___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_5_vuex_router_sync__);
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.


// import Vuex from 'vuex'




window.jQuery = __WEBPACK_IMPORTED_MODULE_0_jquery___default.a
window.$ = __WEBPACK_IMPORTED_MODULE_0_jquery___default.a

__webpack_require__(45)
__webpack_require__(48)
__webpack_require__(44)
__webpack_require__(43)
__WEBPACK_IMPORTED_MODULE_1_vue__["a" /* default */].config.productionTip = false

__webpack_require__.i(__WEBPACK_IMPORTED_MODULE_5_vuex_router_sync__["sync"])(__WEBPACK_IMPORTED_MODULE_4__store__["a" /* default */], __WEBPACK_IMPORTED_MODULE_3__router__["a" /* default */])

/* eslint-disable no-new */
new __WEBPACK_IMPORTED_MODULE_1_vue__["a" /* default */]({
  el: '#app',
  store: __WEBPACK_IMPORTED_MODULE_4__store__["a" /* default */],
  router: __WEBPACK_IMPORTED_MODULE_3__router__["a" /* default */],
  template: '<App/>',
  components: { App: __WEBPACK_IMPORTED_MODULE_2__App___default.a }
})


/***/ }),
/* 86 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const getters = {
  getProductById: (state, getters) => (id) => {
    return state.products.find(product => product.id)
  }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = getters;



/***/ }),
/* 87 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// state.js
const state = {
  count: 0,
  componentLayout: 'vertical'
}
/* harmony export (immutable) */ __webpack_exports__["a"] = state;



/***/ }),
/* 88 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 89 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 90 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 91 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 92 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 93 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 94 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 95 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 96 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 97 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 98 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 99 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 100 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 101 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 102 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 103 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 104 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 105 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 106 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 107 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 108 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 109 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 110 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 111 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 112 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 113 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 114 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 115 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 116 */
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),
/* 117 */,
/* 118 */,
/* 119 */,
/* 120 */,
/* 121 */,
/* 122 */,
/* 123 */,
/* 124 */,
/* 125 */,
/* 126 */,
/* 127 */,
/* 128 */,
/* 129 */,
/* 130 */,
/* 131 */,
/* 132 */,
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/vue-yeti.076c405.jpg";

/***/ }),
/* 134 */
/***/ (function(module, exports) {

module.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDE0IDc5LjE1Njc5NywgMjAxNC8wOC8yMC0wOTo1MzowMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6OTk2QkI4RkE3NjE2MTFFNUE4NEU4RkIxNjQ5MTYyRDgiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6OTk2QkI4Rjk3NjE2MTFFNUE4NEU4RkIxNjQ5MTYyRDgiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjU2QTEyNzk3NjkyMTFFMzkxODk4RDkwQkY4Q0U0NzYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NjU2QTEyN0E3NjkyMTFFMzkxODk4RDkwQkY4Q0U0NzYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5WHowqAAAXNElEQVR42uxda4xd1XVe53XvvD2eGQ/lXQcKuDwc2eFlCAGnUn7kT6T86J/+aNTgsWPchJJYciEOCQ8hF+G0hFCIHRSEqAuJBCqRaUEIEbmBppAIBGnESwZje8COZ+y587j3PLq+ffadGJix53HvPevcuz60xPjec89ZZ+39nf04+9vLSZKEFArFzHA1BAqFEkShUIIoFEoQhUIJolAoQRQKJYhCoQRRKJQgCoUSRKFQKEEUCiWIQrFo+Gv/8/YH+f/nsMWSHHMChyhxqPTTdyncWyJ3ScD/ztipiB3wXSqu6P17avN+TyFC5ggv4tRnmoxWTP1+5F+Mz17GPvPl49EKBWd3UsfXllPiso8VcYtmPba3fNuKrBVXrGFCbrdPwXndFL49ltI367roOpSUI4pGypv9s7q+ltj6JxqOQ07Bo/DgxGb2/a8cX0CnAWXJ5etz2TqdHiXHKlKj9w6i9XX8Ic41DmI8FVHhmmXk85MmRhCzJoiTWnig9LfJRHihgydxzAxJhBr7Bh/hK3yu+p9568FliTJF2aKMZfVd/kQOcKP6OBmS9+Rjm4zJ6faoeN0gOUn61MncLX4CJ+MRhe+P/dRxhfew2Df4CF/hs4jWg8vQYUKYMuWyRRkLjeHQ8YP0Z9mekVjA8Qj3VVcuoeDiXu63lkUE0ym6FA5PXBaNVr7qtPumGyPR4Bt8hK/wWUR5chn6XJYoU5StUHL8l+XEx2axhkS6yk+chJuP4rXLyOkIKJkS0B67adcqfL/0Y4pixxSysK6V8Yl9Mz7i3272NRFlhzJsu24Z5l9E9Ahmwfrpoj7uw3fZtktsRZKjIXnndlLxin7+W8ZTBwPf6I+Tg9HwxK2Ob8citbCoBoaxBxMCvsFH+CqjHCtUvLzflKWUcpwB91gupG5f9/Rtx39ZZBtmWyJtphKzHTQW0diP36b4aJmcLj/zGaSkHJPb4SWFi/tOJd8bTqd9s48VBRh4RKeUX/vjgXg8cpyCmz05xkJylxSoa8M5RF0eJaVIIkGOsg2yTc3UgpD94psiWxEOqDNYoOIXuHnGwE5AXUTFi46FTnRw4l/dwEm7/pSxcYnCF/gE3zInh52RRJkVP7/MlKFQcgCbjifHTAQBfsb2qsgBO3e1Cpf3UXBej3nRJKKrxU/rcH/pKzz4vNIQuRJTEmZklbg6EL4SPsE3GQPzinmfhbJDGQolB+r8w58abs5y8DqRt4ABeptLRR7koY9NleybEYw/MPisvF/ayT1/SvDewcnIcG32wfiCAbEvoCZyGaGsitdyz6XdTctQJq6fcT5mloNfYvu5yFZkpEz+RT0UrFoqpxVBV+vQxIrkaPnrbqdvXs6hcjbU+Jq4Nvvwd/BFRNeq2npwWfkX95iyE9p6PM72P/MhCPANTBSKu5WITHcC074Y9CUTkYglKBgcV/aVtlM5Kpp/RHFjDdfka7MP/2wG6m72661QNigjlBXKTGBtsjWKNs5atCf44Uds3xc5YD8Wknd2BxWuGjCzIxLWQzlFj+IjU108OL7bafM5sm5DDdfka/8T+9AJXyTMpqFsUEYoK5SZ0NbjVlvX500Q4Ha2A+JuCcEvhVS8qp/8MzspHhMSfO7mVPaP35BMRp9JsCQldbX+hmvxNfnamzJfqVvtWnGZoGxQRigroYs6UbfvOGHn4ORVkTaIbEWwtqg3MNO+Zql0JGCdVuCayhDuG9uJB7vp+oR17FbZc+NauCauLWLmKkqXr6NsUEYoK6GtxwY6CXXnEs0n2faIHLCPhhR8bikFKwRN+xZddHWu5a7Ol9yCZ2ZwHKdOxufGNeKRqS/hmnLWW1VMmQSrl5oyEkqOPbZu02IJAsic9sU7B+5uF9cOmqUfeLOdOaAZYb/CA+M/Ic9NxUoYMNfD/PT84f7xB807EAnrrbgMUBZt1w1SEpCIqfjF1Om5EuQNth0iu1r8tPLP76LCpX2yWpHDk2dGH018p6brtD5hOHf04cR3okOTZ0lqPVAW3gVdlMhdrfsTW6drRhDgRrYJcbeKZQxTkenvegNt6YBQwrQvOxG+P3ZHEia9TuClS9Br1XKge8XnxLlxjelzZ/2w4tijDMxyoHIsVQg1zvYPcy7KeZx4jG2zyFakFJF7Whu1XT2QvhfJeryeVNdplYPo4Pi9hKd7VVxVC8O5cH4+N65hXgoKuGfEHmWAskjGxI49Ntu6XHOCAD9ie1PcLSepjDNY00fB8m6KpSyJx/jgg9LfJEfLK40818w+LXY5e5zKaMfKl+DcIlSCZp0cd3U59igDI4+WOa2LunvfvDoD9RrcNLqAjDy3yzfrtKqbAkggSDIZmSlYxzz9a8BaJ101zF2rh3BuSTJaCKGMDEGujHbedXch0X2ebbdEkkDC6a9cQoWVguS53P0JP5xcHY1W/tppD9KxgrdAw5QxnwPn4nOukrPeqkzBJb0m9oJltLtt3a07QYD1IkMAeS7/hw0BXMhzJwXJc/eV7kuiyIN8OOGuUhLP06JUeoxz4FxiZLRouTsDM9WO2OdBRtsIgrzHtk3kgH00JO+cTipc2S9jqyCaluf2xwcnfuB6LndHuEsSzdP4N/gtzoFzSZHRIsaQQiPmidyXgttsnW0YQYDvsh2ROGBPxkMqXjNA/qlCFsnZ8UdlX+kfk0pymlnMWH2JOBfz0sWI+C3OMS1dzPphhPVWHOPC5wdMzIUOzFFHb1lwB2ARF+ZOPt0gshWBPLe/wCRZlu6CIkSei/cE0fD4g2ZbVWceyxH5WPwGvzXrrSTJaDnG7oBoGS3qaCULggCPsv1W5IAd8tzLllJwvpx1WthMIfyg9OVotHy1WVQ4V37wsfgNfkuSZLQcW8Q4lruU/RVbRykrggDXiwwN3uQWnXTa1xMkz2W/on2lndNajpNtAGePw2/MOicBMlqs+8K7GBNbjrFgGe2iX0nUgiAvs+0S2YpgndaFPVRc3SdmVanZlfGjifOiw5PrT/oGvPpG/vDkEH4jZ70Vt86rl5rYimmdP41/s3Uzc4Isup9XNxwvz+0tyNAlONPrtO6hctR+QnluKqNt52O3pxvtClhvxTH0egtmEwbBMlrUxU21OFGtCHKYbavIATv3j90z26kIea4QZRtahfhIuT0anrjH7O3rpjNVHzPIaLG3Lh8Tj5TbRQihjlNyehxTwTLarbZOiiEIcBfbPnGhMtroChXW9JN/VqeYdyPEY4nwwPj6ZCL8C1T+T61JhDqRv8MxZgwlJG2BxzEsrBmgeEzseqt9ti6SNIIA8t6wm901eFDZ66d7M4UkQ56LVgTTvvtKaRqFqoTWymjxGb6LpUzrImYcuzaOIWKJmAptPWpaB2sd+V+yvSB1wB6s7qXgwiUyBpbJdBqFq6MjU18mKCKhRsTyEbx558/wnRmYJzLiV+DYBat6JQ/MX7B1UCxBAKHy3IQrH6W7MhY9MWkUMNAN948/8Mm35/jMDIKlpC3gmBWQtsAjifkE61b36kGQP7DdL7KrVZXnXiYpjYKZxj09Gh7f4kB4yIa/8ZmU1brIIYiYIXaJ3Nbjflv3xBME+DZbSVwIzfIIK89dJkSea18Ihu+XflD9yPztCJnW5Ri5VRntpNh8giVb5ygvBIHu9yaRrchYRO6fFU0CSTPQlDLte6zshx9O3g3D3yJajySd4EDaAsQMsRPaetxk61zty+YTCXRqjf9jO19cOLnyYV+p8QffpcreMXJ7BeRgh77Ds6SIYhGbMBgB2tld1DW0nGL4VxbZfKBbdUHdhol1dl7mOi0MOjttGgWT11lAwU9r1mMSsX0oxwSxgYyWOvKXtiAvBPkV239I7GqZdVqX9FDw2V5+UoYipn2nt/WRMK3LMQlW9poYCZ7WfcrWsdwSBNggMrRYdcLdhjas0+q28lzJOc8bOU7jWLh2AwzEyLxclYm6Z2ZuBEE+YLtTZEVA9tzPdBh5biJ3q5rGD8yRjXbNAPkcm0RuyjTUqf3NQBDge2yHJFaGeDyi4tUD5J3WIXmzs8Y9NDgG3un80OCYIDZCHxqHbJ2iZiEIGmnB8twgzYIkd7vMxiBON59GLJyBQLKMdiM1qOPXyMn2f2f7X5EDdshzkUbhAtED0oZMXCAGiIXgtAW/YXusURdr9NsoufLcgmP20zKy2ErrNSNGRuunMUAshL7zABq61q/RBPkd2yNSn57+X3ZTQZA8t7H3H5p7RwwEt6KP2DrUtAQBIIUsiwt99Kf+tydFntuocVhVRltNWyBTRlumGslopRNkhO1mkRVlLCT3jHYzqyU48WSN+1ZWRou0BZDRyp3Ju9nWnaYnCHA3216JlQWy0gKy557dJSaNQn0nKNL1VrhnwTLavbbOUKsQBBApzzVpFHqsPFdIGoW6AfeG7cMwrcv3TC0io80LQZ5me07kU3WkYqSlhYvkpFGoz8C8bO7RyGjlpi14ztaVliMIIFOeizQKbpI+WdsDGfLcWvcmsaK53b4gdUW3lENZXjxrgrzNdq/IAftohbzzOql4eV/zjUUcu96K7w33KFhGi7rxVisTBEBSxWPiiqYqz71mGfmDQuS5tSIHstHyPZnd7+XKaI+RgKSxEggySWmKaXkVaSwi5xSbRmGiSdZpxVZGy/eEexMso73R1o2WJwiwk+11kQNZrNO6oo+Cc7vz39Wy07q4l+CKfnNvQu/ndVsnSAkifcCOAXq7R8W1y9JdRvI87QvfnTRtgdPeujLavBLkv9meEPnUHS2Tf1EPFT67lOKRnE77munrsrkH/+IeydPXqAO/VoLMDMhz5T2irTzXpFHoKeRPnluV0XYX0mlduTLamIRJtKUR5CDbbSIrGPfX/eUdVFyTQ3luku6OaNIW/HmH5LQFt9k6oAQ5Ab7PNiyxkmGndUhRvTNyJM9F1wrZaM9IZbQmG63MocewxIejRIKg+DaKbEXGI3KWBtT2hUFKyonUZeEfB3xkX4vsM3wXvIx/IwmMqCu0WH/B9qLIpzG6Wp/rpWBFj/x1WnaCAb4G7LPgad0XbZmTEmTukDnti0yzgZvKcwNPtDzXyGjZR5ONFincVEbbVAR5je0hkU/lkTL5F3TZzQ2EvjysJr1hH/0LuiVPTz9ky1oJsgB8iwQsN5hplISns5Hn9hXl9eurMlr2zUzrVsQuk5m0ZUxKkIXhKNsWkQN2yHNPhzx3WbqQMRZGYCOjXWZ8FDzjtsWWsRJkEfgh2zvyOvhWnovsucu75GTPtdlo4RN8i+W+s3nHli0pQRaPIXEeVeW53V46YJciz2Uf4IvxiX0juW/9h/JQ8fJCkGfZnpE5YK9QsHIJBZcIkOdW141d3Gt8EiyjfcaWqRKk6Z84kOc6duODjmzluUZGyz4g6Q18UhltaxHkXbbtIgfsRyvknQt5bobZc6dltP3Gl0SudmW7LUslSJ1mPUbFeWVUepDnDpB3SgazRtW0BXxt+ABfhE7rypyVbCKCTLF9U2QrgjQKg3b7zskGv3eI0+XsuDZ8EJy2YJMtQyVIHfEztldFDtghz728j4LzGphGoZq2gK9ZMDuwiH3ngTJ7OG+VLY8EAeTKc9ts9lwk42zEOi2st+JrYZIA1xYso12Xx4qWV4K8xPZzka3ISCrPDVY1YJ1WtfVYZWW0ctdbPW7LTAnSQHyDJCoykEYhTNdpuUsK6YDZqQ85cG5cw6y3CsWmLYBXG/NayfJMkI8oVR/KG7AfC8k7u4MKVw2kM1r1eB2RpDNXuAauJVhGe6stKyVIBrid7YA4r6o5N5BG4cxOI3mtaeWtymj53LiG4FwmKJs78lzB8k4QVIsN4ryqynN7AzP1ShXIc2tYg3GuSpJO6/aKltHK3KWmhQgCPMm2R+SAfTSkANlzV9Rw2rc6MDcyWtHZaPfYsiElSPaQOYVYiSnxiIprB8kpeGn+v8U2mZD8FjxzTpybKjqtqwQ5Od5g2yGyq4Xsued3UeHSvsW3IlUZLZ8L5xSctmCHLRMliCBgN/AJcV7F6SpbjBe8gUWkUaimLeBzmOUsU2JltOMkcbd+JQiNkYB8ErNVbPe0Nmq72i4kXMiwNUnfe+AcOJfgfCWbbVkoQQTiR2xvivPKynODNX0ULF9AGoVq2gL+Lc4hWEaL2N/XTBWq2Qgic3BYled2+ekeVfOV51az0WKNF59DsIx2XbNVpmYkyPNsuyWSBBJYf+USKsxHnlvNRsu/8WXLaHfb2CtBcoD1Ir2CPJf/wxSt2xmkupGT9c6QtoCPNdO66FfJldGub8aK1KwEeY9tm8gB+2hI3jmdVLii/+RbBdktfHAsfpPIfSm4zcZcCZIjfJftiMQBO1IQQBrrn3qCRYZ20SOOMTLacbHrrRDjW5q1EjUzQbiTTzeIbEUgz+232XNne59RfX+CbLT9omW0iHFFCZJPPMr2W5EDdshzL1tKwfkzrNOqrrfi73CMYBntKzbGpATJL64X6RXWZRVtxlnP+VgaBZO2wEu/wzGatkAJUk+8zLZLZCuCdVoXciux+rhVuXYVMD7Dd7Hc9Va7bGyVIE0Amf3kaXnuIHm9qTwXhr/xmWAZbUXk+E4JsmAcZtsqcsAOee6Z7VS08lwY/sZngmW0W21MlSBNhLvY9onzCqtIxipUuKqf3L6iMfyNz4RO6+6zsWwJ+NRawNvep8S1IhMxucie+8VT0o+6PIqPiB17rG+lCtNqBPkl2wts14gbsCONwqVLzT8Fr7d6wcawZeBS60Hm1GSSTu+a6d5EY6cEyQ5/YLtf4oCd4iQ1ma3H/TZ2SpAWwLfZSqSYK0o2ZqQEaQ1AN32T1vs54yYbMyVIC+GBVuwyLLBL+kCr3rzb4oV/vdZ/jZESZHb8iqS9F5GFp2yMlCAtjCENgcZGCTI79rPdqWH4FO60sVGCKOh7bIc0DNM4ZGNCShAFEFKOsyDVARttTJQgGoJpPMb2Gw2DicFjGgYlyExYpyHQGChBZsfv2B5p4ft/xMZAoQSZFZso3TKo1VC2965QgpwQI2w3t+B932zvXaEEOSnuZtvbQve7196zQgkyZ6zXe1UoQWbH02zPtcB9PmfvVaEEmTeG9B6VIIrZ8RbbvU18f/fae1QoQRYMJKU81oT3dYwkJj1VguQOk9REaY2Pw4323hRKkEVjJ9vrTXQ/r9t7UihBaobr9V6UIIrZ8Wu2J5rgPp6w96JQgtQcG2jmhGl5QWzvQaEEqQsOst2WY/9vs/egUILUtZIN59Dv4ZyTWwmSEyDnUx7luRtJar4qJUjT4RdsL+bI3xetzwolSMOwTn1Vgihmx2tsD+XAz4esrwolSMPxLZK9XGPS+qhQgmSCo2xbBPu3xfqoUIJkhh+yvSPQr3esbwolSOYYUp+UIIrZ8SzbM4L8ecb6pFCC6BNbWw8lSB7wLtt2AX5st74olCDikPWskfRZNSVIi2OKst2+c5P1QaEEEYuH2V7N4Lqv2msrlCDisa5FrqkEUSwIL7E93sDrPW6vqVCC5AaN0l/kVZ+iBGlxfMR2awOuc6u9lkIJkjvcwXagjuc/YK+hUILkEgnVdxeRDfYaCiVIbvEk2546nHePPbdCCZJ7rMvJORVKkEzwBtuOGp5vhz2nQgnSNMBu6uM1OM84Nedu80qQFscY1SYfx2Z7LoUSpOlwH9ubi/j9m/YcCiWIDth1YK4EaUU8z7Z7Ab/bbX+rUII0PdY36DcKJUgu8R7btnkcv83+RqEEaRncwnZkDscdsccqlCAthQrbDXM47gZ7rEIJ0nJ4lO2VE3z/ij1GoQRpWaxb4HcKJUhL4GW2XTN8vst+p1CCtDw+Oc6Y6/hEoQRpCRxm23rcv7fazxRKEIXFXZRuwBDZvxUC4GsIREHflguDkyQqaVYotIulUChBFAoliEKhBFEolCAKhRJEoVCCKBRKEIVCCaJQKJQgCoUSRKFQgigUShCFIhP8vwADACog5YM65zugAAAAAElFTkSuQmCC"

/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(93)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(52),
  /* template */
  __webpack_require__(161),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-3bd21be1",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(114)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(53),
  /* template */
  __webpack_require__(185),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-ec5b19ea",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(110)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(55),
  /* template */
  __webpack_require__(181),
  /* styles */
  injectStyle,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(111)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(61),
  /* template */
  __webpack_require__(182),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-bfbb8252",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(107)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(62),
  /* template */
  __webpack_require__(177),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-7a7731ea",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(65),
  /* template */
  __webpack_require__(174),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(66),
  /* template */
  __webpack_require__(159),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(67),
  /* template */
  __webpack_require__(178),
  /* styles */
  null,
  /* scopeId */
  null,
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(103)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(70),
  /* template */
  __webpack_require__(172),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-6911ce95",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(97)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(71),
  /* template */
  __webpack_require__(165),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-57ad3854",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(109)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(76),
  /* template */
  __webpack_require__(180),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-7fbbeb49",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(105)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(78),
  /* template */
  __webpack_require__(175),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-714dd4f4",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(116)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(79),
  /* template */
  __webpack_require__(187),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-f605c9f2",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(95)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(80),
  /* template */
  __webpack_require__(163),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-484b0c94",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(108)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(81),
  /* template */
  __webpack_require__(179),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-7bc959e0",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(112)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(82),
  /* template */
  __webpack_require__(183),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-d5db1fee",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(96)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(83),
  /* template */
  __webpack_require__(164),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-5509b8c8",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

function injectStyle (ssrContext) {
  __webpack_require__(88)
}
var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(84),
  /* template */
  __webpack_require__(153),
  /* styles */
  injectStyle,
  /* scopeId */
  "data-v-046c504d",
  /* moduleIdentifier (server only) */
  null
)

module.exports = Component.exports


/***/ }),
/* 153 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("Tabs are elements that help you organize and navigate multiple documents in a single container. They can be used for switching between items in the container.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('tabs', {
    attrs: {
      "panels": _vm.panels,
      "id": _vm.id,
      "auto-focus": _vm.autoFocus,
      "wrap-on-keys": _vm.wrapOnKeys,
      "match-height": _vm.matchHeight,
      "active-collapse": _vm.activeCollapse,
      "deep-link": _vm.deepLink,
      "deep-link-smudge": _vm.deepLinkSmudge,
      "deep-link-smudge-delay": _vm.deepLinkSmudgeDelay,
      "link-class": _vm.linkClass,
      "link-active-class": _vm.linkActiveClass,
      "panel-class": _vm.panelClass,
      "panel-active-class": _vm.panelActiveClass,
      "update-history": _vm.updateHistory,
      "expand-tabs": _vm.expandTabs
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Auto Focus")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "autoFocus",
      "name": "autoFocus",
      "checked": _vm.autoFocus
    },
    model: {
      value: (_vm.autoFocus),
      callback: function($$v) {
        _vm.autoFocus = $$v
      },
      expression: "autoFocus"
    }
  })], 1)]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Expand Tabs")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "expandTabs",
      "name": "expandTabs",
      "checked": _vm.expandTabs
    },
    model: {
      value: (_vm.expandTabs),
      callback: function($$v) {
        _vm.expandTabs = $$v
      },
      expression: "expandTabs"
    }
  })], 1)]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Wrap On Keys")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "wrapOnKeys",
      "name": "wrapOnKeys",
      "checked": _vm.wrapOnKeys
    },
    model: {
      value: (_vm.wrapOnKeys),
      callback: function($$v) {
        _vm.wrapOnKeys = $$v
      },
      expression: "wrapOnKeys"
    }
  })], 1)]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Match Height")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "matchHeight",
      "name": "matchHeight",
      "checked": _vm.matchHeight
    },
    model: {
      value: (_vm.matchHeight),
      callback: function($$v) {
        _vm.matchHeight = $$v
      },
      expression: "matchHeight"
    }
  })], 1)]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Update History")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "updateHistory",
      "name": "updateHistory",
      "checked": _vm.updateHistory
    },
    model: {
      value: (_vm.updateHistory),
      callback: function($$v) {
        _vm.updateHistory = $$v
      },
      expression: "updateHistory"
    }
  })], 1)]), _vm._v(" "), _vm._m(4)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Active Collapse")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "activeCollapse",
      "name": "activeCollapse",
      "checked": _vm.activeCollapse
    },
    model: {
      value: (_vm.activeCollapse),
      callback: function($$v) {
        _vm.activeCollapse = $$v
      },
      expression: "activeCollapse"
    }
  })], 1)]), _vm._v(" "), _vm._m(5)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Deep Link")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "deepLink",
      "name": "deepLink",
      "checked": _vm.deepLink
    },
    model: {
      value: (_vm.deepLink),
      callback: function($$v) {
        _vm.deepLink = $$v
      },
      expression: "deepLink"
    }
  })], 1)]), _vm._v(" "), _vm._m(6)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Deep Link Smudge")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "deepLinkSmudge",
      "name": "deepLinkSmudge",
      "checked": _vm.deepLinkSmudge
    },
    model: {
      value: (_vm.deepLinkSmudge),
      callback: function($$v) {
        _vm.deepLinkSmudge = $$v
      },
      expression: "deepLinkSmudge"
    }
  })], 1)]), _vm._v(" "), _vm._m(7)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Smudge Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.deepLinkSmudgeDelay),
      expression: "deepLinkSmudgeDelay",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "deepLinkSmudgeDelay",
      "id": "deepLinkSmudgeDelay"
    },
    domProps: {
      "value": _vm.deepLinkSmudgeDelay,
      "value": (_vm.deepLinkSmudgeDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.deepLinkSmudgeDelay = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(8)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Link Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.linkClass),
      expression: "linkClass"
    }],
    attrs: {
      "type": "text",
      "name": "linkClass",
      "id": "linkClass"
    },
    domProps: {
      "value": _vm.linkClass,
      "value": (_vm.linkClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.linkClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(9)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Link Active Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.linkActiveClass),
      expression: "linkActiveClass"
    }],
    attrs: {
      "type": "text",
      "name": "linkActiveClass",
      "id": "linkActiveClass"
    },
    domProps: {
      "value": _vm.linkActiveClass,
      "value": (_vm.linkActiveClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.linkActiveClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(10)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Panel Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.panelClass),
      expression: "panelClass"
    }],
    attrs: {
      "type": "text",
      "name": "panelClass",
      "id": "panelClass"
    },
    domProps: {
      "value": _vm.panelClass,
      "value": (_vm.panelClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.panelClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(11)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Panel Active Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.panelActiveClass),
      expression: "panelActiveClass"
    }],
    attrs: {
      "type": "text",
      "name": "panelActiveClass",
      "id": "panelActiveClass"
    },
    domProps: {
      "value": _vm.panelActiveClass,
      "value": (_vm.panelActiveClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.panelActiveClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(12)]), _vm._v(" "), _c('hr')])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the window to scroll to content of active pane on load if set to true. Not recommended if more than one tab panel per page.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Makes the tab links evenly distibute across the container.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows keyboard input to 'wrap' around the tab links.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the tab content panes to match heights if set to true.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Update the browser history with the open tab.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows active tabs to collapse when clicked.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the window to scroll to content of pane specified by hash anchor.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Adjust the deep link scroll to make sure the top of the tab panel is visible.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Animation time (ms) for the deep link adjustment.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to `li`'s in tab link list.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the active `li` in tab link list.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the content containers.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the active content container.")])])])
}]}

/***/ }),
/* 154 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "slider ",
    class: [_vm.isVertical === true ? 'vertical' : '', _vm.isDisabled === true ? 'disabled' : ''],
    attrs: {
      "id": this.sliderID,
      "data-vertical": _vm.isVertical === true ? 'true' : 'false',
      "data-slider": "",
      "data-initial-start": this.dataValue,
      "data-end": this.dataEnd,
      "data-step": this.stepValue
    }
  }, [_c('span', {
    staticClass: "slider-handle",
    attrs: {
      "data-slider-handle": "",
      "role": "slider",
      "tabindex": "1"
    }
  }), _vm._v(" "), _c('span', {
    staticClass: "slider-fill",
    attrs: {
      "data-slider-fill": ""
    }
  }), _vm._v(" "), _c('input', {
    staticClass: "slider-input",
    attrs: {
      "type": "hidden"
    }
  })]), _vm._v(" "), _c('p', [_vm._v("Value: " + _vm._s(_vm.dataValue))])])
},staticRenderFns: []}

/***/ }),
/* 155 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    class: ['switch', _vm.switchSize ? _vm.switchSize : '']
  }, [(_vm.switchMode === 'checkbox') ? _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.value),
      expression: "value"
    }],
    staticClass: "switch-input",
    attrs: {
      "id": _vm.switchId,
      "type": "checkbox",
      "name": _vm.switchName
    },
    domProps: {
      "checked": _vm.checked,
      "checked": Array.isArray(_vm.value) ? _vm._i(_vm.value, null) > -1 : (_vm.value)
    },
    on: {
      "__c": function($event) {
        var $$a = _vm.value,
          $$el = $event.target,
          $$c = $$el.checked ? (true) : (false);
        if (Array.isArray($$a)) {
          var $$v = null,
            $$i = _vm._i($$a, $$v);
          if ($$el.checked) {
            $$i < 0 && (_vm.value = $$a.concat($$v))
          } else {
            $$i > -1 && (_vm.value = $$a.slice(0, $$i).concat($$a.slice($$i + 1)))
          }
        } else {
          _vm.value = $$c
        }
      }
    }
  }) : (_vm.switchMode === 'radios') ? _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.value),
      expression: "value"
    }],
    staticClass: "switch-input",
    attrs: {
      "id": _vm.switchId,
      "type": "radio",
      "name": _vm.switchName
    },
    domProps: {
      "checked": _vm.checked,
      "checked": _vm._q(_vm.value, null)
    },
    on: {
      "__c": function($event) {
        _vm.value = null
      }
    }
  }) : _vm._e(), _vm._v(" "), _c('label', {
    staticClass: "switch-paddle",
    attrs: {
      "for": _vm.switchId
    }
  }, [_c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("Download Kittens")]), _vm._v(" "), (_vm.activeLabel) ? _c('span', {
    staticClass: "switch-active",
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v(_vm._s(_vm.activeLabel))]) : _vm._e(), _vm._v(" "), (_vm.inactiveLabel) ? _c('span', {
    staticClass: "switch-inactive",
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v(_vm._s(_vm.inactiveLabel))]) : _vm._e()])])
},staticRenderFns: []}

/***/ }),
/* 156 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('ul', {
    staticClass: "accordion",
    attrs: {
      "id": _vm.id,
      "data-accordion": ""
    }
  }, _vm._l((_vm.panels), function(panel, index) {
    return _c('accordion-tab', {
      key: index,
      class: [index === 0 ? 'is-active' : '', 'accordion-item'],
      attrs: {
        "index": index,
        "panel": panel
      }
    })
  }))])
},staticRenderFns: []}

/***/ }),
/* 157 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return (!_vm.readOnly) ? _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.amount),
      expression: "amount"
    }],
    ref: "numeric",
    attrs: {
      "placeholder": _vm.placeholder,
      "type": "tel"
    },
    domProps: {
      "value": _vm.value,
      "value": (_vm.amount)
    },
    on: {
      "blur": _vm.formatValue,
      "input": [function($event) {
        if ($event.target.composing) { return; }
        _vm.amount = $event.target.value
      }, function($event) {
        _vm.processValue(_vm.amountValue)
      }],
      "focus": function($event) {
        _vm.convertToNumber(_vm.numberValue)
      }
    }
  }) : _c('span', {
    ref: "readOnly"
  }, [_vm._v(" " + _vm._s(_vm.amount) + " ")])
},staticRenderFns: []}

/***/ }),
/* 158 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    staticClass: "pagination",
    attrs: {
      "role": "navigation",
      "aria-label": "Pagination"
    }
  }, [_c('li', {
    staticClass: "pagination-previous disabled"
  }, [_vm._v("Previous "), _c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("page")])]), _vm._v(" "), _c('li', {
    staticClass: "current"
  }, [_c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("You're on page")]), _vm._v(" 1")]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Page 2"
    }
  }, [_vm._v("2")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Page 3"
    }
  }, [_vm._v("3")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Page 4"
    }
  }, [_vm._v("4")])]), _vm._v(" "), _c('li', {
    staticClass: "ellipsis",
    attrs: {
      "aria-hidden": "true"
    }
  }), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Page 12"
    }
  }, [_vm._v("12")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Page 13"
    }
  }, [_vm._v("13")])]), _vm._v(" "), _c('li', {
    staticClass: "pagination-next"
  }, [_c('a', {
    attrs: {
      "href": "#",
      "aria-label": "Next page"
    }
  }, [_vm._v("Next "), _c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("page")])])])])
}]}

/***/ }),
/* 159 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('nav', _vm._l((_vm.images), function(image, index) {
    return _c('button', {
      class: index === 0 ? 'is-active' : '',
      attrs: {
        "data-slide": index
      }
    }, [_c('span', {
      staticClass: "show-for-sr",
      attrs: {
        "value": image.title
      }
    }), _vm._v(" "), (index === 0) ? _c('span', {
      staticClass: "show-for-sr"
    }, [_vm._v("Current Slide")]) : _vm._e()])
  }))
},staticRenderFns: []}

/***/ }),
/* 160 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    class: ['vertical', 'menu'],
    attrs: {
      "id": _vm.id,
      "data-accordion-menu": "",
      "data-submenu-toggle": _vm.submenuToggle
    }
  }, _vm._l((_vm.menu), function(link, index) {
    return _c('li', {
      class: [
        _vm.submenuToggle ? 'has-submenu-toggle' : '',
        (link.submenu && _vm.submenuToggle) ? 'is-accordion-submenu-parent' : ''
      ]
    }, [(link.mode === 'router' || (_vm.mode === 'router' && link.mode !== 'standard')) ? _c('router-link', {
      attrs: {
        "to": link.target,
        "exact": ""
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]) : _c('a', {
      attrs: {
        "href": link.target
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]), _vm._v(" "), (link.submenu) ? _c('standard-menu', {
      attrs: {
        "submenu-toggle": _vm.submenuToggle,
        "menu": link.submenu,
        "vertical": true
      }
    }) : _vm._e(), _vm._v(" "), (_vm.submenuToggle && link.submenu) ? _c('button', {
      staticClass: "submenu-toggle"
    }) : _vm._e()], 1)
  }))
},staticRenderFns: []}

/***/ }),
/* 161 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "blogpost-footer"
  }, [_vm._m(0), _vm._v(" "), _c('div', {
    staticClass: "blogpost-footer-author-section"
  }, [_c('div', [_c('a', {
    staticClass: "blogpost-footer-author",
    attrs: {
      "href": "#"
    }
  }, [_c('img', {
    staticClass: "avatar",
    attrs: {
      "src": "https://fillmurray.com/200/200",
      "alt": ""
    }
  }), _vm._v(" "), _c('div', [_c('p', {
    staticClass: "author"
  }, [_vm._v(_vm._s(this.author))]), _vm._v(" "), _c('p', {
    staticClass: "bio"
  }, [_vm._v(_vm._s(this.bio))])])])]), _vm._v(" "), _c('a', {
    staticClass: "hollow button success",
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Follow")])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "blogpost-footer-actions"
  }, [_c('div', {
    staticClass: "blogpost-footer-actions-left"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-heart-o",
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v(" 4")])]), _vm._v(" "), _c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-comment-o",
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v(" 2")])])]), _vm._v(" "), _c('div', {
    staticClass: "blogpost-footer-actions-right"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-twitter-square",
    attrs: {
      "aria-hidden": "true"
    }
  })]), _vm._v(" "), _c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-facebook-official",
    attrs: {
      "aria-hidden": "true"
    }
  })])])])
}]}

/***/ }),
/* 162 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "orbit",
    attrs: {
      "id": "orbit",
      "role": "region",
      "aria-label": _vm.label,
      "data-orbit": ""
    }
  }, [_c('ul', {
    staticClass: "orbit-container"
  }, [(_vm.navButtons) ? _c('orbit-arrow', {
    class: _vm.prevClass,
    attrs: {
      "direction": "prev"
    }
  }) : _vm._e(), _vm._v(" "), (_vm.navButtons) ? _c('orbit-arrow', {
    class: _vm.nextClass,
    attrs: {
      "direction": "next"
    }
  }) : _vm._e(), _vm._v(" "), _vm._l((_vm.images), function(image, index) {
    return _c('orbit-slide', {
      key: index,
      class: [index === 0 ? 'is-active' : '', _vm.slideClass],
      attrs: {
        "image": image
      }
    })
  })], 2), _vm._v(" "), (_vm.bullets) ? _c('orbit-bullets', {
    class: _vm.boxOfBullets,
    attrs: {
      "images": _vm.images
    }
  }) : _vm._e()], 1)
},staticRenderFns: []}

/***/ }),
/* 163 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-8 medium-offset-2 columns"
  }, [_c('h2', [_vm._v("Accordion")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Accordions are elements that help you organize and navigate multiple documents in a single container. They can be used for switching between items in the container.")]), _vm._v(" "), _c('accordion'), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Accordion Menu")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('accordion-menu', {
    attrs: {
      "menu": _vm.mainMenu,
      "submenuToggle": false
    }
  }), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Breadcrumbs")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Breadcrumbs come in handy to show a navigation trail for users clicking through your site.")]), _vm._v(" "), _c('breadcrumbs'), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Drilldown Menu")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Drilldown is one of Foundation's three menu patterns, which converts a series of nested lists into a vertical drilldown menu.")]), _vm._v(" "), _c('drilldown-menu', {
    attrs: {
      "menu": _vm.mainMenu
    }
  }), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Dropdown")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Dropdown panes are little happy sprites which can be revealed on click or hover.")]), _vm._v(" "), _c('dropdown'), _vm._v(" "), _c('hr'), _vm._v(" "), _c('h2', [_vm._v("Dropdown Menu")]), _vm._v(" "), _c('dropdown-menu', {
    attrs: {
      "menu": _vm.mainMenu
    }
  }), _vm._v(" "), _c('hr'), _vm._v(" "), _c('h2', [_vm._v("Magellan")]), _vm._v(" "), _c('p', [_vm._v("Magellan allows you to create navigation that tracks the active section of a page your user is in.")]), _vm._v(" "), _c('magellan'), _vm._v(" "), _c('hr'), _vm._v(" "), _c('h2', [_vm._v("Orbit")]), _vm._v(" "), _c('p', [_vm._v("An image and content carousel with animation support and many customizable options.")]), _vm._v(" "), _c('orbit'), _vm._v(" "), _c('hr'), _vm._v(" "), _c('h2', [_vm._v("Pagination")]), _vm._v(" "), _c('p', [_vm._v("Pagination is a type of navigation that lets users click through pages of search results, products, or other related items.")]), _vm._v(" "), _c('pagination'), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Reveal")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Modal dialogs, or pop-up windows, are handy for prototyping and production.")]), _vm._v(" "), _c('reveal', {
    attrs: {
      "closeButton": true
    }
  }, [_c('h1', [_vm._v("Awesome. I Have It.")]), _vm._v(" "), _c('p', {
    staticClass: "lead"
  }, [_vm._v("Your couch. It is mine.")]), _vm._v(" "), _c('p', [_vm._v("I'm a cool paragraph that lives inside of an even cooler modal. Wins!")])]), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Slider")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("This handy lil slider is perfect for setting specific values within a range.")]), _vm._v(" "), _c('slider'), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Switch")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Create pure CSS3 On/Off switches with animated transitions. A massive turn on for your users.")]), _vm._v(" "), _c('h4', [_vm._v("Checkboxes")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": 'switchOne',
      "name": 'switchOne',
      "size": 'tiny'
    }
  }), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": 'switchTwo',
      "name": 'switchTwo',
      "size": 'small',
      "checked": true
    }
  }), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": 'switchThree',
      "name": 'switchThree'
    }
  }), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": 'switchFour',
      "size": 'large',
      "activeText": 'On',
      "inactiveText": 'Off',
      "mode": 'checkbox',
      "name": 'switchFour',
      "checked": true
    }
  }), _vm._v(" "), _c('h4', [_vm._v("Radios")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "activeText": 'On',
      "inactiveText": 'Off',
      "id": 'radioSwitchOne',
      "name": 'radioSwitchGroup',
      "size": 'large',
      "mode": 'radio'
    }
  }), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "activeText": 'On',
      "inactiveText": 'Off',
      "id": 'radioSwitchTwo',
      "name": 'radioSwitchGroup',
      "size": 'large',
      "checked": true,
      "mode": 'radio'
    }
  }), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Tabs")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Tabs are elements that help you organize and navigate multiple documents in a single container. They can be used for switching between items in the container.")]), _vm._v(" "), _c('tabs'), _vm._v(" "), _c('hr')], 1)]), _vm._v(" "), _c('h2', [_vm._v("Tooltip")]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('p', [_vm._v("Tooltips? More like Cooltips. But really though, tooltips are nifty for displaying extended information for a term or action on a page.")]), _vm._v(" "), _c('tooltip'), _vm._v(" "), _c('hr')], 1)])])])
},staticRenderFns: []}

/***/ }),
/* 164 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("Modal dialogs, or pop-up windows, are handy for prototyping and production. Foundation includes Reveal, our jQuery modal plugin, to make this easy for you.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('reveal', {
    attrs: {
      "close-button": _vm.closeButton,
      "animation-in": _vm.animationIn,
      "animation-out": _vm.animationOut,
      "show-delay": _vm.showDelay,
      "hide-delay": _vm.hideDelay,
      "close-on-click": _vm.closeOnClick,
      "close-on-esc": _vm.closeOnEsc,
      "multiple-opened": _vm.multipleOpened,
      "v-offset": _vm.vOffset,
      "h-offset": _vm.hOffset,
      "full-screen": _vm.fullScreen,
      "bottom-offset-pct": _vm.bottomOffsetPct,
      "overlay": _vm.overlay,
      "reset-on-close": _vm.resetOnClose,
      "deep-link": _vm.deepLink,
      "update-history": _vm.updateHistory,
      "append-to": _vm.appendTo,
      "additional-overlay-classes": _vm.additionalOverlayClasses
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Close Button")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "closeButton",
      "name": "closeButton",
      "checked": _vm.closeButton
    },
    model: {
      value: (_vm.closeButton),
      callback: function($$v) {
        _vm.closeButton = $$v
      },
      expression: "closeButton"
    }
  })], 1)]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Animation In")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.animationIn),
      expression: "animationIn",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "text",
      "name": "animationIn",
      "id": "animationIn"
    },
    domProps: {
      "value": _vm.animationIn,
      "value": (_vm.animationIn)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animationIn = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Animation Out")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.animationOut),
      expression: "animationOut",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "text",
      "name": "animationOut",
      "id": "animationOut"
    },
    domProps: {
      "value": _vm.animationOut,
      "value": (_vm.animationOut)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animationOut = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Show Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.showDelay),
      expression: "showDelay",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "showDelay",
      "id": "showDelay"
    },
    domProps: {
      "value": _vm.showDelay,
      "value": (_vm.showDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.showDelay = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Hide Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.hideDelay),
      expression: "hideDelay",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "hideDelay",
      "id": "hideDelay"
    },
    domProps: {
      "value": _vm.hideDelay,
      "value": (_vm.hideDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.hideDelay = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(4)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Close on Click")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "closeOnClick",
      "name": "closeOnClick",
      "checked": _vm.closeOnClick
    },
    model: {
      value: (_vm.closeOnClick),
      callback: function($$v) {
        _vm.closeOnClick = $$v
      },
      expression: "closeOnClick"
    }
  })], 1)]), _vm._v(" "), _vm._m(5)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Close on Escape")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "closeOnEsc",
      "name": "closeOnEsc",
      "checked": _vm.closeOnEsc
    },
    model: {
      value: (_vm.closeOnEsc),
      callback: function($$v) {
        _vm.closeOnEsc = $$v
      },
      expression: "closeOnEsc"
    }
  })], 1)]), _vm._v(" "), _vm._m(6)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Multiple Opened")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "multipleOpened",
      "name": "multipleOpened",
      "checked": _vm.multipleOpened
    },
    model: {
      value: (_vm.multipleOpened),
      callback: function($$v) {
        _vm.multipleOpened = $$v
      },
      expression: "multipleOpened"
    }
  })], 1)]), _vm._v(" "), _vm._m(7)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Vertical Offset")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.vOffset),
      expression: "vOffset"
    }],
    attrs: {
      "type": "text",
      "name": "vOffset",
      "id": "vOffset"
    },
    domProps: {
      "value": _vm.vOffset,
      "value": (_vm.vOffset)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.vOffset = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(8)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Horizontal Offset")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.hOffset),
      expression: "hOffset"
    }],
    attrs: {
      "type": "text",
      "name": "hOffset",
      "id": "hOffset"
    },
    domProps: {
      "value": _vm.hOffset,
      "value": (_vm.hOffset)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.hOffset = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(9)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Full Screen")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "fullScreen",
      "name": "fullScreen",
      "checked": _vm.fullScreen
    },
    model: {
      value: (_vm.fullScreen),
      callback: function($$v) {
        _vm.fullScreen = $$v
      },
      expression: "fullScreen"
    }
  })], 1)]), _vm._v(" "), _vm._m(10)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Bottom Offset Percent")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.bottomOffsetPct),
      expression: "bottomOffsetPct",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "bottomOffsetPct",
      "id": "bottomOffsetPct"
    },
    domProps: {
      "value": _vm.bottomOffsetPct,
      "value": (_vm.bottomOffsetPct)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.bottomOffsetPct = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(11)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Overlay")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "overlay",
      "name": "overlay",
      "checked": _vm.overlay
    },
    model: {
      value: (_vm.overlay),
      callback: function($$v) {
        _vm.overlay = $$v
      },
      expression: "overlay"
    }
  })], 1)]), _vm._v(" "), _vm._m(12)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Reset on Close")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "resetOnClose",
      "name": "resetOnClose",
      "checked": _vm.resetOnClose
    },
    model: {
      value: (_vm.resetOnClose),
      callback: function($$v) {
        _vm.resetOnClose = $$v
      },
      expression: "resetOnClose"
    }
  })], 1)]), _vm._v(" "), _vm._m(13)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Deep Link")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "deepLink",
      "name": "deepLink",
      "checked": _vm.deepLink
    },
    model: {
      value: (_vm.deepLink),
      callback: function($$v) {
        _vm.deepLink = $$v
      },
      expression: "deepLink"
    }
  })], 1)]), _vm._v(" "), _vm._m(14)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Update History")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "updateHistory",
      "name": "updateHistory",
      "checked": _vm.updateHistory
    },
    model: {
      value: (_vm.updateHistory),
      callback: function($$v) {
        _vm.updateHistory = $$v
      },
      expression: "updateHistory"
    }
  })], 1)]), _vm._v(" "), _vm._m(15)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Append To")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.appendTo),
      expression: "appendTo",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "text",
      "name": "appendTo",
      "id": "appendTo"
    },
    domProps: {
      "value": _vm.appendTo,
      "value": (_vm.appendTo)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.appendTo = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(16)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Additional Overlay Classes")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.additionalOverlayClasses),
      expression: "additionalOverlayClasses",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "text",
      "name": "additionalOverlayClasses",
      "id": "additionalOverlayClasses"
    },
    domProps: {
      "value": _vm.additionalOverlayClasses,
      "value": (_vm.additionalOverlayClasses)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.additionalOverlayClasses = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(17)])])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Whether the Reveal should have a close button.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion-UI class to use for animated elements. If none used, defaults to simple show/hide.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion-UI class to use for animated elements. If none used, defaults to simple show/hide.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Time, in ms, to delay the opening of a modal after a click if no animation used.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Time, in ms, to delay the closing of a modal after a click if no animation used.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows a click on the body/overlay to close the modal.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to close if the user presses the `ESCAPE` key.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("If true, allows multiple modals to be displayed at once.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Distance, in pixels, the modal should push down from the top of the screen.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Distance, in pixels, the modal should push in from the side of the screen.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to be fullscreen, completely blocking out the rest of the view. JS checks for this as well.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Percentage of screen height the modal should push up from the bottom of the view.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to generate an overlay div, which will cover the view when modal opens.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to remove and reinject markup on close. Should be true if using video elements w/o using provider's api, otherwise, videos will continue to play in the background.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to alter the url on open/close, and allows the use of the `back` button to close modals. ALSO, allows a modal to auto-maniacally open on page load IF the hash === the modal's user-set id.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Update the browser history with the open modal.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the modal to append to custom div.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows adding additional class names to the reveal overlay.")])])])
}]}

/***/ }),
/* 165 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    class: ['button'],
    attrs: {
      "data-open": _vm.revealId
    }
  }, [_vm._v(_vm._s(_vm.buttonText))])
},staticRenderFns: []}

/***/ }),
/* 166 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    class: [
      'menu',
      _vm.verticalLayout ? 'vertical' : '',
      _vm.linkAlignment === 'left' ? 'align-left' : '',
      _vm.linkAlignment === 'right' ? 'align-right' : '',
      _vm.linkAlignment === 'center' ? 'align-center' : '',
      _vm.expandMenu ? 'expanded' : ''
    ]
  }, _vm._l((_vm.menuStructure), function(link) {
    return _c('li', [(link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) ? _c('router-link', {
      attrs: {
        "to": link.target,
        "exact": ""
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]) : _c('a', {
      attrs: {
        "href": link.target
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]), _vm._v(" "), (link.submenu) ? _c('standard-menu', {
      attrs: {
        "menu": link.submenu,
        "mode": _vm.menuMode,
        "vertical": _vm.verticalLayout,
        "alignment": _vm.linkAlignment,
        "expanded": _vm.expandMenu
      }
    }) : _vm._e()], 1)
  }))
},staticRenderFns: []}

/***/ }),
/* 167 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    staticClass: "vertical menu drilldown",
    attrs: {
      "id": "drilldown",
      "data-drilldown": "",
      "data-auto-height": "true",
      "data-animate-height": "true"
    }
  }, _vm._l((_vm.menuStructure), function(link) {
    return _c('li', [((link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) && link.target) ? _c('router-link', {
      attrs: {
        "to": link.target,
        "exact": ""
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]) : _c('a', {
      attrs: {
        "href": link.target
      }
    }, [_vm._v(_vm._s(link.title))]), _vm._v(" "), (link.submenu) ? _c('ul', {
      staticClass: "menu vertical",
      attrs: {
        "data-submenu": ""
      }
    }, _vm._l((link.submenu), function(link) {
      return _c('li', [((link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) && link.target) ? _c('router-link', {
        attrs: {
          "to": link.target,
          "exact": ""
        }
      }, [_vm._v("\n          " + _vm._s(link.title) + "\n        ")]) : _c('a', {
        attrs: {
          "href": link.target
        }
      }, [_vm._v("\n          " + _vm._s(link.title) + "\n        ")])], 1)
    })) : _vm._e()], 1)
  }))
},staticRenderFns: []}

/***/ }),
/* 168 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('p', [_vm._v("\nThe "), _c('span', {
    staticClass: "has-tip",
    attrs: {
      "data-tooltip": "",
      "aria-haspopup": "true",
      "tabindex": "1",
      "title": "Fancy word for a beetle."
    }
  }, [_vm._v("scarabaeus")]), _vm._v(" hung quite clear of any branches, and, if allowed to fall, would have fallen at our feet. Legrand immediately took the scythe, and cleared with it a circular space, three or four yards in diameter, just beneath the insect, and, having accomplished this, ordered Jupiter to let go the string and come down from the tree.\n")])
}]}

/***/ }),
/* 169 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('nav', {
    attrs: {
      "aria-label": "You are here:",
      "role": "navigation"
    }
  }, [_c('ul', {
    staticClass: "breadcrumbs"
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Home")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_vm._v("Features")])]), _vm._v(" "), _c('li', {
    staticClass: "disabled"
  }, [_vm._v("Gene Splicing")]), _vm._v(" "), _c('li', [_c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("Current: ")]), _vm._v(" Cloning\n    ")])])])
}]}

/***/ }),
/* 170 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('ul', {
    class: ['tabs', _vm.expandTabs ? 'expanded' : ''],
    attrs: {
      "id": _vm.id,
      "data-tabs": ""
    }
  }, _vm._l((_vm.panels), function(panel, index) {
    return _c('li', {
      class: [_vm.linkClass, index === 0 ? _vm.linkActiveClass : '']
    }, [_c('a', {
      attrs: {
        "href": '#panel' + index + 'd'
      }
    }, [_vm._v(_vm._s(panel.title))])])
  })), _vm._v(" "), _c('div', {
    staticClass: "tabs-content",
    attrs: {
      "data-tabs-content": "tabs"
    }
  }, _vm._l((_vm.panels), function(panel, index) {
    return _c('div', {
      class: [_vm.panelClass, index === 0 ? _vm.panelActiveClass : ''],
      attrs: {
        "id": 'panel' + index + 'd'
      }
    }, [_c('p', [_vm._v(_vm._s(panel.content))])])
  }))])
},staticRenderFns: []}

/***/ }),
/* 171 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _vm._m(0)
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('ul', {
    staticClass: "horizontal menu",
    attrs: {
      "id": "magellan",
      "data-magellan": ""
    }
  }, [_c('li', [_c('a', {
    attrs: {
      "href": "#first"
    }
  }, [_vm._v("First")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#second"
    }
  }, [_vm._v("Second")])]), _vm._v(" "), _c('li', [_c('a', {
    attrs: {
      "href": "#third"
    }
  }, [_vm._v("Third")])])]), _vm._v(" "), _c('div', {
    staticClass: "sections"
  }, [_c('section', {
    attrs: {
      "id": "first",
      "data-magellan-target": "first"
    }
  }, [_c('span', [_vm._v("First Section")])]), _vm._v(" "), _c('section', {
    attrs: {
      "id": "second",
      "data-magellan-target": "second"
    }
  }, [_c('span', [_vm._v("Second Section")])]), _vm._v(" "), _c('section', {
    attrs: {
      "id": "third",
      "data-magellan-target": "third"
    }
  }, [_c('span', [_vm._v("Third Section")])])])])
}]}

/***/ }),
/* 172 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "reveal",
    attrs: {
      "id": _vm.id,
      "data-reveal": ""
    }
  }, [_vm._t("default"), _vm._v(" "), (_vm.closeButton) ? _c('button', {
    staticClass: "close-button",
    attrs: {
      "data-close": "",
      "aria-label": "Close modal",
      "type": "button"
    }
  }, [_c('span', {
    attrs: {
      "aria-hidden": "true"
    }
  }, [_vm._v("×")])]) : _vm._e()], 2)
},staticRenderFns: []}

/***/ }),
/* 173 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('ul', {
    staticClass: "dropdown menu",
    attrs: {
      "id": "dropdown-menu",
      "data-dropdown-menu": ""
    }
  }, _vm._l((_vm.menuStructure), function(link, index) {
    return _c('li', [(link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) ? _c('router-link', {
      attrs: {
        "to": link.target,
        "exact": ""
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]) : _c('a', {
      attrs: {
        "href": link.target
      }
    }, [_vm._v("\n      " + _vm._s(link.title) + "\n    ")]), _vm._v(" "), (link.submenu) ? _c('ul', {
      staticClass: "menu vertical"
    }, _vm._l((link.submenu), function(sublink) {
      return _c('li', [(link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) ? _c('router-link', {
        attrs: {
          "to": sublink.target,
          "exact": ""
        }
      }, [_vm._v("\n          " + _vm._s(sublink.title) + "\n        ")]) : _c('a', {
        attrs: {
          "href": sublink.target
        }
      }, [_vm._v("\n          " + _vm._s(sublink.title) + "\n        ")])], 1)
    })) : _vm._e()], 1)
  }))
},staticRenderFns: []}

/***/ }),
/* 174 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return ((this.$props.direction === 'prev')) ? _c('button', [_c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("Previous Slide")]), _vm._v("◀︎")]) : ((this.$props.direction === 'next')) ? _c('button', [_c('span', {
    staticClass: "show-for-sr"
  }, [_vm._v("Next Slide")]), _vm._v("▶︎")]) : _vm._e()
},staticRenderFns: []}

/***/ }),
/* 175 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("You can use this component for creating menus based on the Zurb Foundation accordion menu.")]), _vm._v(" "), _c('p', [_vm._v("The only valid prop for the component at the moment is a menu array. Each item in the array MUST have a title and a target. They can also have an option class string for setting custom classes and a mode prop.")]), _vm._v(" "), _c('p', [_vm._v("The mode prop is for setting the internal link mode to use either the Vue Router or set a standard anchor tag. The options are 'router' (Default) and 'standard'.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('accordion-menu', {
    attrs: {
      "menu": _vm.menu,
      "submenu-toggle": _vm.submenuToggle,
      "submenu-toggle-text": _vm.submenuToggleText,
      "slide-speed": _vm.slideSpeed,
      "multi-open": _vm.multiOpen,
      "mode": 'router'
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Slide Speed")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.slideSpeed),
      expression: "slideSpeed",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "slideSpeed",
      "id": "slideSpeed"
    },
    domProps: {
      "value": _vm.slideSpeed,
      "value": (_vm.slideSpeed)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.slideSpeed = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Submenu Toggle")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "submenuToggle",
      "name": "submenuToggle",
      "checked": _vm.submenuToggle
    },
    model: {
      value: (_vm.submenuToggle),
      callback: function($$v) {
        _vm.submenuToggle = $$v
      },
      expression: "submenuToggle"
    }
  })], 1)]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Submenu Toggle Text")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.submenuToggleText),
      expression: "submenuToggleText"
    }],
    attrs: {
      "id": "submenuToggleText",
      "name": "submenuToggleText"
    },
    domProps: {
      "value": (_vm.submenuToggleText)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.submenuToggleText = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Multi Open")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "multiOpen",
      "name": "multiOpen",
      "checked": _vm.multiOpen
    },
    model: {
      value: (_vm.multiOpen),
      callback: function($$v) {
        _vm.multiOpen = $$v
      },
      expression: "multiOpen"
    }
  })], 1)]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr')])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Amount of time to animate the opening of a submenu in ms.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Adds a separate submenu toggle button. This allows the parent item to have a link.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The text used for the submenu toggle if enabled. This is used for screen readers only.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow the menu to have multiple open panes.")])])])
}]}

/***/ }),
/* 176 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('reveal-content', {
    attrs: {
      "id": _vm.id,
      "close-button": _vm.closeButton
    }
  }, [_vm._t("default", [_vm._v(_vm._s(_vm.msg))])], 2), _vm._v(" "), _c('reveal-trigger', {
    attrs: {
      "id": _vm.id
    }
  })], 1)
},staticRenderFns: []}

/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "row align-middle"
  }, [_c('div', {
    staticClass: "small-10 medium-5 small-offset-1 columns image"
  }, [_c('img', {
    attrs: {
      "src": __webpack_require__(133)
    }
  })]), _vm._v(" "), _c('div', {
    staticClass: "small-12 medium-5 columns"
  }, [_c('h1', [_vm._v(_vm._s(_vm.msg))]), _vm._v(" "), _c('p', [_vm._v("This is a demo integration of Foundation for Sites 6.3 in a VueJS 2.2 single-page application.")]), _vm._v(" "), _vm._m(0), _vm._v(" "), _vm._m(1)])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "button secondary call-button",
    attrs: {
      "data-toggle": "offCanvas"
    }
  }, [_c('i', {
    staticClass: "icon-puzzle"
  }), _vm._v("JS Components")])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('a', {
    staticClass: "button secondary hollow call-button",
    attrs: {
      "href": "https://github.com/vue-foundation/vue-foundation"
    }
  }, [_c('i', {
    staticClass: "icon-github-circled"
  }), _vm._v("Source")])
}]}

/***/ }),
/* 178 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('li', {
    staticClass: "orbit-slide"
  }, [_c('img', {
    staticClass: "orbit-image",
    attrs: {
      "src": _vm.image.url,
      "alt": _vm.image.alt
    }
  }), _vm._v(" "), _c('figcaption', {
    staticClass: "orbit-caption show-for-medium"
  }, [_vm._v(_vm._s(_vm.image.title))])])
},staticRenderFns: []}

/***/ }),
/* 179 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("Dropdown panes are little happy sprites which can be revealed on click or hover.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('dropdown', {
    attrs: {
      "button-text": _vm.buttonText,
      "content": _vm.content,
      "id": _vm.id,
      "hover": _vm.hover,
      "v-offset": _vm.vOffset,
      "h-offset": _vm.hOffset,
      "position": _vm.position,
      "alignment": _vm.alignment
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Button Text")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.buttonText),
      expression: "buttonText"
    }],
    attrs: {
      "type": "text",
      "name": "buttonText",
      "id": "buttonText"
    },
    domProps: {
      "value": _vm.buttonText,
      "value": (_vm.buttonText)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.buttonText = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("ID")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.id),
      expression: "id"
    }],
    attrs: {
      "type": "text",
      "id": "id",
      "name": "id"
    },
    domProps: {
      "value": (_vm.id)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.id = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Content")]), _vm._v(" "), _c('textarea', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.content),
      expression: "content"
    }],
    attrs: {
      "rows": "5",
      "type": "text",
      "id": "content",
      "name": "content"
    },
    domProps: {
      "value": (_vm.content)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.content = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Parent Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.parentClass),
      expression: "parentClass"
    }],
    attrs: {
      "type": "text",
      "id": "parentClass",
      "name": "parentClass"
    },
    domProps: {
      "value": (_vm.parentClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.parentClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Hover Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.hoverDelay),
      expression: "hoverDelay",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "hoverDelay",
      "id": "hoverDelay"
    },
    domProps: {
      "value": _vm.hoverDelay,
      "value": (_vm.hoverDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.hoverDelay = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(4)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Hover")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "hover",
      "name": "hover",
      "checked": _vm.hover
    },
    model: {
      value: (_vm.hover),
      callback: function($$v) {
        _vm.hover = $$v
      },
      expression: "hover"
    }
  })], 1)]), _vm._v(" "), _vm._m(5)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Hover Pane")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "hoverPane",
      "name": "hoverPane",
      "checked": _vm.hoverPane
    },
    model: {
      value: (_vm.hoverPane),
      callback: function($$v) {
        _vm.hoverPane = $$v
      },
      expression: "hoverPane"
    }
  })], 1)]), _vm._v(" "), _vm._m(6)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Vertical Offset")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.vOffset),
      expression: "vOffset"
    }],
    attrs: {
      "type": "text",
      "name": "vOffset",
      "id": "vOffset"
    },
    domProps: {
      "value": _vm.vOffset,
      "value": (_vm.vOffset)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.vOffset = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(7)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Horizontal Offset")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.hOffset),
      expression: "hOffset"
    }],
    attrs: {
      "type": "text",
      "name": "hOffset",
      "id": "hOffset"
    },
    domProps: {
      "value": _vm.hOffset,
      "value": (_vm.hOffset)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.hOffset = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(8)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Position Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.positionClass),
      expression: "positionClass"
    }],
    attrs: {
      "type": "text",
      "name": "positionClass",
      "id": "positionClass"
    },
    domProps: {
      "value": _vm.positionClass,
      "value": (_vm.positionClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.positionClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(9)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Position")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.position),
      expression: "position"
    }],
    attrs: {
      "type": "text",
      "name": "position",
      "id": "position"
    },
    domProps: {
      "value": _vm.position,
      "value": (_vm.position)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.position = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(10)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("alignment")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.alignment),
      expression: "alignment"
    }],
    attrs: {
      "type": "text",
      "name": "alignment",
      "id": "alignment"
    },
    domProps: {
      "value": _vm.alignment,
      "value": (_vm.alignment)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.alignment = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(11)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Allow Overlap")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "allowOverlap",
      "name": "allowOverlap",
      "checked": _vm.allowOverlap
    },
    model: {
      value: (_vm.allowOverlap),
      callback: function($$v) {
        _vm.allowOverlap = $$v
      },
      expression: "allowOverlap"
    }
  })], 1)]), _vm._v(" "), _vm._m(12)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Allow Bottom Overlap")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "allowBottomOverlap",
      "name": "allowBottomOverlap",
      "checked": _vm.allowBottomOverlap
    },
    model: {
      value: (_vm.allowBottomOverlap),
      callback: function($$v) {
        _vm.allowBottomOverlap = $$v
      },
      expression: "allowBottomOverlap"
    }
  })], 1)]), _vm._v(" "), _vm._m(13)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Trap Focus")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "trapFocus",
      "name": "trapFocus",
      "checked": _vm.trapFocus
    },
    model: {
      value: (_vm.trapFocus),
      callback: function($$v) {
        _vm.trapFocus = $$v
      },
      expression: "trapFocus"
    }
  })], 1)]), _vm._v(" "), _vm._m(14)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Auto Focus")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "autoFocus",
      "name": "autoFocus",
      "checked": _vm.autoFocus
    },
    model: {
      value: (_vm.autoFocus),
      callback: function($$v) {
        _vm.autoFocus = $$v
      },
      expression: "autoFocus"
    }
  })], 1)]), _vm._v(" "), _vm._m(15)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Close on Click")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "closeOnClick",
      "name": "closeOnClick",
      "checked": _vm.closeOnClick
    },
    model: {
      value: (_vm.closeOnClick),
      callback: function($$v) {
        _vm.closeOnClick = $$v
      },
      expression: "closeOnClick"
    }
  })], 1)]), _vm._v(" "), _vm._m(16)])])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The text for the Dropdown trigger button.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The ID of the dropdown.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The dropdown content.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class that designates bounding container of Dropdown.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Amount of time to delay opening a submenu on hover event.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow submenus to open on hover events.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Don't close dropdown when hovering over dropdown pane.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Distance, in pixels, the modal should push down from the top of the screen.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Distance, in pixels, the modal should push in from the side of the screen.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("DEPRECATED: Class applied to adjust open position.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Position of dropdown. Can be left, right, bottom, top, or auto.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Alignment of dropdown relative to anchor. Can be left, right, bottom, top, center, or auto.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow overlap of container/window. If false, dropdown will first try to position as defined by data-position and data-alignment, but reposition if it would cause an overflow.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow overlap of only the bottom of the container. This is the most common behavior for dropdowns, allowing the dropdown to extend the bottom of the screen but not otherwise influence or break out of the container.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow the plugin to trap focus to the dropdown pane if opened with keyboard commands.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allow the plugin to set focus to the first focusable element within the pane, regardless of method of opening.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows a click on the body/overlay to close the modal.")])])])
}]}

/***/ }),
/* 180 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('nav', [_c('div', {
    staticClass: "top-bar",
    attrs: {
      "id": "responsive-menu"
    }
  }, [_c('div', {
    staticClass: "top-bar-left"
  }, [_c('ul', {
    staticClass: "menu dropdown",
    attrs: {
      "id": "main-dropdown-menu",
      "data-dropdown-menu": ""
    }
  }, _vm._l((_vm.leftMenu), function(link) {
    return (link.target) ? _c('li', {
      class: [link.class ? link.class : '']
    }, [((link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) && link.target) ? _c('router-link', {
      attrs: {
        "to": link.target,
        "exact": ""
      }
    }, [_vm._v("\n            " + _vm._s(link.title) + "\n          ")]) : _c('a', {
      attrs: {
        "href": link.target
      }
    }, [_vm._v("\n            " + _vm._s(link.title) + "\n          ")]), _vm._v(" "), (link.submenu) ? _c('ul', {
      staticClass: "menu vertical",
      attrs: {
        "data-submenu": ""
      }
    }, _vm._l((link.submenu), function(link) {
      return _c('li', [((link.mode === 'router' || (_vm.menuMode === 'router' && link.mode !== 'standard')) && link.target) ? _c('router-link', {
        attrs: {
          "to": link.target,
          "exact": ""
        }
      }, [_vm._v("\n                " + _vm._s(link.title) + "\n              ")]) : _c('a', {
        attrs: {
          "href": link.target
        }
      }, [_vm._v("\n                " + _vm._s(link.title) + "\n              ")])], 1)
    })) : _vm._e()], 1) : _c('li', {
      class: [link.class ? link.class : '']
    }, [_vm._v("\n          " + _vm._s(link.title) + "\n        ")])
  }))]), _vm._v(" "), _c('div', {
    staticClass: "top-bar-right"
  })])])
},staticRenderFns: []}

/***/ }),
/* 181 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('li', {
    class: [_vm.index === 0 ? 'is-active' : '', 'accordion-item'],
    attrs: {
      "data-accordion-item": ""
    }
  }, [_c('a', {
    staticClass: "accordion-title",
    attrs: {
      "href": [_vm.dL === true ? '#accordion-' + (_vm.index + 1) : '#']
    }
  }, [_vm._v(_vm._s(_vm.panel.title))]), _vm._v(" "), _c('div', {
    staticClass: "accordion-content",
    attrs: {
      "data-tab-content": ""
    }
  }, [_vm._v("\n    " + _vm._s(_vm.panel.content) + "\n  ")])])
},staticRenderFns: []}

/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "hello"
  }, [_c('img', {
    attrs: {
      "src": __webpack_require__(134)
    }
  }), _vm._v(" "), _c('h1', [_vm._v(_vm._s(_vm.msg))]), _vm._v(" "), _c('h2', [_vm._v("Essential Links")]), _vm._v(" "), _vm._m(0), _vm._v(" "), _c('h2', [_vm._v("Ecosystem")]), _vm._v(" "), _vm._m(1)])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "button-group"
  }, [_c('a', {
    staticClass: "button",
    attrs: {
      "href": "https://vuejs.org",
      "target": "_blank"
    }
  }, [_vm._v("Core Docs")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "https://forum.vuejs.org",
      "target": "_blank"
    }
  }, [_vm._v("Forum")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "https://gitter.im/vuejs/vue",
      "target": "_blank"
    }
  }, [_vm._v("Gitter Chat")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "https://twitter.com/vuejs",
      "target": "_blank"
    }
  }, [_vm._v("Twitter")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "http://vuejs-templates.github.io/webpack/",
      "target": "_blank"
    }
  }, [_vm._v("Template Docs")])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "small button-group"
  }, [_c('a', {
    staticClass: "button",
    attrs: {
      "href": "http://router.vuejs.org/",
      "target": "_blank"
    }
  }, [_vm._v("vue-router")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "http://vuex.vuejs.org/",
      "target": "_blank"
    }
  }, [_vm._v("vuex")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "http://vue-loader.vuejs.org/",
      "target": "_blank"
    }
  }, [_vm._v("vue-loader")]), _vm._v(" "), _c('a', {
    staticClass: "button",
    attrs: {
      "href": "https://github.com/vuejs/awesome-vue",
      "target": "_blank"
    }
  }, [_vm._v("awesome-vue")])])
}]}

/***/ }),
/* 183 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("Tabs are elements that help you organize and navigate multiple documents in a single container. They can be used for switching between items in the container.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('orbit', {
    attrs: {
      "auto-play": _vm.autoPlay,
      "slides": _vm.slides,
      "container-class": _vm.containerClass,
      "slide-class": _vm.slideClass,
      "box-of-bullets": _vm.boxOfBullets,
      "prev-class": _vm.prevClass,
      "next-class": _vm.nextClass,
      "anim-in-from-right": _vm.animInFromRight,
      "anim-out-to-right": _vm.animOutToRight,
      "anim-in-from-left": _vm.animInFromLeft,
      "anim-out-to-left": _vm.animOutToLeft,
      "geo-sync": _vm.geoSync,
      "accessible": _vm.accessible,
      "use-m-u-i": _vm.useMUI,
      "pause-on-hover": _vm.pauseOnHover,
      "swipe": _vm.swipe,
      "bullets": _vm.bullets,
      "infinite-wrap": _vm.infiniteWrap,
      "nav-buttons": _vm.navButtons,
      "timer-delay": _vm.timerDelay
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Bullets")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "bullets",
      "name": "bullets",
      "checked": _vm.bullets
    },
    model: {
      value: (_vm.bullets),
      callback: function($$v) {
        _vm.bullets = $$v
      },
      expression: "bullets"
    }
  })], 1)]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Nav Buttons")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "navButtons",
      "name": "navButtons",
      "checked": _vm.navButtons
    },
    model: {
      value: (_vm.navButtons),
      callback: function($$v) {
        _vm.navButtons = $$v
      },
      expression: "navButtons"
    }
  })], 1)]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Anim In From Right")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.animInFromRight),
      expression: "animInFromRight"
    }],
    attrs: {
      "id": "animInFromRight",
      "name": "animInFromRight"
    },
    domProps: {
      "value": (_vm.animInFromRight)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animInFromRight = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Anim Out To Right")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.animOutToRight),
      expression: "animOutToRight"
    }],
    attrs: {
      "id": "animOutToRight",
      "name": "animOutToRight"
    },
    domProps: {
      "value": (_vm.animOutToRight)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animOutToRight = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Anim In From Left")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.animInFromLeft),
      expression: "animInFromLeft"
    }],
    attrs: {
      "id": "animInFromLeft",
      "name": "animInFromLeft"
    },
    domProps: {
      "value": (_vm.animInFromLeft)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animInFromLeft = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(4)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Anim Out To Left")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.animOutToLeft),
      expression: "animOutToLeft"
    }],
    attrs: {
      "id": "animOutToLeft",
      "name": "animOutToLeft"
    },
    domProps: {
      "value": (_vm.animOutToLeft)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.animOutToLeft = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(5)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Auto Play")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "autoPlay",
      "name": "autoPlay",
      "checked": _vm.autoPlay
    },
    model: {
      value: (_vm.autoPlay),
      callback: function($$v) {
        _vm.autoPlay = $$v
      },
      expression: "autoPlay"
    }
  })], 1)]), _vm._v(" "), _vm._m(6)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Timer Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.timerDelay),
      expression: "timerDelay"
    }],
    attrs: {
      "id": "timerDelay",
      "name": "timerDelay"
    },
    domProps: {
      "value": (_vm.timerDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.timerDelay = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(7)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Infinite Wrap")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "infiniteWrap",
      "name": "infiniteWrap",
      "checked": _vm.infiniteWrap
    },
    model: {
      value: (_vm.infiniteWrap),
      callback: function($$v) {
        _vm.infiniteWrap = $$v
      },
      expression: "infiniteWrap"
    }
  })], 1)]), _vm._v(" "), _vm._m(8)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Swipe")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "swipe",
      "name": "swipe",
      "checked": _vm.swipe
    },
    model: {
      value: (_vm.swipe),
      callback: function($$v) {
        _vm.swipe = $$v
      },
      expression: "swipe"
    }
  })], 1)]), _vm._v(" "), _vm._m(9)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Pause on Hover")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "pauseOnHover",
      "name": "pauseOnHover",
      "checked": _vm.pauseOnHover
    },
    model: {
      value: (_vm.pauseOnHover),
      callback: function($$v) {
        _vm.pauseOnHover = $$v
      },
      expression: "pauseOnHover"
    }
  })], 1)]), _vm._v(" "), _vm._m(10)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Accessible")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "accessible",
      "name": "accessible",
      "checked": _vm.accessible
    },
    model: {
      value: (_vm.accessible),
      callback: function($$v) {
        _vm.accessible = $$v
      },
      expression: "accessible"
    }
  })], 1)]), _vm._v(" "), _vm._m(11)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Container Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.containerClass),
      expression: "containerClass"
    }],
    attrs: {
      "id": "containerClass",
      "name": "containerClass"
    },
    domProps: {
      "checked": _vm.containerClass,
      "value": (_vm.containerClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.containerClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(12)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Slide Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.slideClass),
      expression: "slideClass"
    }],
    attrs: {
      "id": "slideClass",
      "name": "slideClass"
    },
    domProps: {
      "checked": _vm.slideClass,
      "value": (_vm.slideClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.slideClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(13)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Box of Bullets")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.boxOfBullets),
      expression: "boxOfBullets"
    }],
    attrs: {
      "id": "boxOfBullets",
      "name": "boxOfBullets"
    },
    domProps: {
      "checked": _vm.boxOfBullets,
      "value": (_vm.boxOfBullets)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.boxOfBullets = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(14)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Prev Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.prevClass),
      expression: "prevClass"
    }],
    attrs: {
      "id": "prevClass",
      "name": "prevClass"
    },
    domProps: {
      "checked": _vm.prevClass,
      "value": (_vm.prevClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.prevClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(15)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Next Class")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.nextClass),
      expression: "nextClass"
    }],
    attrs: {
      "id": "nextClass",
      "name": "nextClass"
    },
    domProps: {
      "checked": _vm.nextClass,
      "value": (_vm.nextClass)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.nextClass = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(16)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Use MUI")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.useMUI),
      expression: "useMUI"
    }],
    attrs: {
      "id": "useMUI",
      "name": "useMUI"
    },
    domProps: {
      "checked": _vm.useMUI,
      "value": (_vm.useMUI)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.useMUI = $event.target.value
      }
    }
  })])]), _vm._v(" "), _vm._m(17)])])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows Orbit to automatically animate on page load.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows Orbit to automatically animate on page load.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion UI animation class to apply.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion UI animation class to apply.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion UI animation class to apply.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Motion UI animation class to apply.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows Orbit to automatically animate on page load.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Amount of time, in ms, between slide transitions.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows Orbit to infinitely loop through the slides.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the Orbit slides to bind to swipe events for mobile. This requires an additional mobile swipe utility library.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows the timing function to pause animation on hover.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Allows Orbit to bind keyboard events to the slider, to animate frames with arrow keys.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the container of Orbit.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to individual slides.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the bullet container.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the `previous` navigation button.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Class applied to the `next` navigation button.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Boolean to flag the js to use motion ui classes or not. Default to true for backwards compatability.")])])])
}]}

/***/ }),
/* 184 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    attrs: {
      "id": "app"
    }
  }, [_c('div', {
    staticClass: "off-canvas position-right",
    attrs: {
      "id": "offCanvas",
      "data-off-canvas": ""
    }
  }, [_c('ul', {
    staticClass: "sidebar-menu",
    attrs: {
      "data-close": "offCanvas"
    }
  }, [_c('li', [_c('router-link', {
    attrs: {
      "to": "/",
      "exact": ""
    }
  }, [_vm._v("Home")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/home",
      "exact": ""
    }
  }, [_vm._v("Home")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/reveal",
      "exact": ""
    }
  }, [_vm._v("Reveal")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/slider",
      "exact": ""
    }
  }, [_vm._v("Slider")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/tooltip",
      "exact": ""
    }
  }, [_vm._v("Tooltip")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/dropdown-menu",
      "exact": ""
    }
  }, [_vm._v("Dropdown Menu")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/drilldown-menu",
      "exact": ""
    }
  }, [_vm._v("Drilldown Menu")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/accordion-menu",
      "exact": ""
    }
  }, [_vm._v("Accordion Menu")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/magellan",
      "exact": ""
    }
  }, [_vm._v("Magellan")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/accordion",
      "exact": ""
    }
  }, [_vm._v("Accordion")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/dropdown",
      "exact": ""
    }
  }, [_vm._v("Dropdown")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/tabs",
      "exact": ""
    }
  }, [_vm._v("Tabs")])], 1), _vm._v(" "), _c('li', [_c('router-link', {
    attrs: {
      "to": "/orbit",
      "exact": ""
    }
  }, [_vm._v("Orbit")])], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "off-canvas-content",
    attrs: {
      "data-off-canvas-content": ""
    }
  }, [_c('top-bar', {
    attrs: {
      "left-menu": _vm.mainMenu,
      "title": _vm.title,
      "menu-mode": _vm.mode
    }
  }, [_c('a', {
    staticClass: "button small menu-button hide-for-medium",
    attrs: {
      "data-toggle": "offCanvas"
    }
  }, [_vm._v("Menu")])]), _vm._v(" "), _c('div', {
    staticClass: "content-wrapper"
  }, [_c('router-view')], 1)], 1)])
},staticRenderFns: []}

/***/ }),
/* 185 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h1', [_vm._v(_vm._s(_vm.msg))]), _vm._v(" "), _vm._m(0)])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "card card-product-hover"
  }, [_c('img', {
    attrs: {
      "src": "http://www.zurb.com/blog/system/images/690/original/blue_bw_web.jpg?1354921642",
      "alt": "sweet foundation shirt"
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "card-product-hover-icons"
  }, [_c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-shopping-cart"
  })]), _vm._v(" "), _c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-star-o"
  })]), _vm._v(" "), _c('a', {
    attrs: {
      "href": "#"
    }
  }, [_c('i', {
    staticClass: "fa fa-share-alt"
  })])]), _vm._v(" "), _c('div', {
    staticClass: "card-product-hover-details"
  }, [_c('h3', {
    staticClass: "card-product-hover-title"
  }, [_vm._v("Legacy Foundation Tee")]), _vm._v(" "), _c('span', {
    staticClass: "card-product-hover-price"
  }, [_vm._v("$15.00")])])])
}]}

/***/ }),
/* 186 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('button', {
    staticClass: "button",
    attrs: {
      "type": "button",
      "data-toggle": _vm.id
    }
  }, [_vm._v(_vm._s(_vm.buttonText))]), _vm._v(" "), _c('div', {
    staticClass: "dropdown-pane top",
    attrs: {
      "id": _vm.id,
      "data-dropdown": ""
    },
    domProps: {
      "innerHTML": _vm._s(_vm.content)
    }
  })])
},staticRenderFns: []}

/***/ }),
/* 187 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('h2', [_vm._v(_vm._s(_vm.title))]), _vm._v(" "), _c('p', [_vm._v("Accordions are elements that help you organize and navigate multiple documents in a single container. They can be used for switching between items in the container.")]), _vm._v(" "), _c('div', {
    staticClass: "callout success"
  }, [_c('accordion', {
    attrs: {
      "panels": _vm.panels,
      "slide-speed": _vm.slideSpeed,
      "allow-all-closed": _vm.allowAllClosed,
      "multi-expand": _vm.multiExpand,
      "deep-link": _vm.deepLink,
      "deep-link-smudge": _vm.deepLinkSmudge,
      "deep-link-smudge-delay": _vm.deepLinkSmudgeDelay,
      "update-history": _vm.updateHistory
    }
  })], 1)])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "medium-10 medium-offset-1 columns"
  }, [_c('div', {
    staticClass: "callout secondary",
    attrs: {
      "id": "debug-panel"
    }
  }, [_c('h2', [_vm._v("Settings")]), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Allow All Closed")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "allowAllClosed",
      "name": "allowAllClosed",
      "checked": _vm.allowAllClosed
    },
    model: {
      value: (_vm.allowAllClosed),
      callback: function($$v) {
        _vm.allowAllClosed = $$v
      },
      expression: "allowAllClosed"
    }
  })], 1)]), _vm._v(" "), _vm._m(0)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Deep Link")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "deepLink",
      "name": "deepLink",
      "checked": _vm.deepLink
    },
    model: {
      value: (_vm.deepLink),
      callback: function($$v) {
        _vm.deepLink = $$v
      },
      expression: "deepLink"
    }
  })], 1)]), _vm._v(" "), _vm._m(1)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Deep Link Smudge")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "deepLinkSmudge",
      "name": "deepLinkSmudge",
      "checked": _vm.deepLinkSmudge
    },
    model: {
      value: (_vm.deepLinkSmudge),
      callback: function($$v) {
        _vm.deepLinkSmudge = $$v
      },
      expression: "deepLinkSmudge"
    }
  })], 1)]), _vm._v(" "), _vm._m(2)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Smudge Delay")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.deepLinkSmudgeDelay),
      expression: "deepLinkSmudgeDelay",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "deepLinkSmudgeDelay",
      "id": "deepLinkSmudgeDelay"
    },
    domProps: {
      "value": _vm.deepLinkSmudgeDelay,
      "value": (_vm.deepLinkSmudgeDelay)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.deepLinkSmudgeDelay = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(3)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Multi Expand")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "multiExpand",
      "name": "multiExpand",
      "checked": _vm.multiExpand
    },
    model: {
      value: (_vm.multiExpand),
      callback: function($$v) {
        _vm.multiExpand = $$v
      },
      expression: "multiExpand"
    }
  })], 1)]), _vm._v(" "), _vm._m(4)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Slide Speed")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.number",
      value: (_vm.slideSpeed),
      expression: "slideSpeed",
      modifiers: {
        "number": true
      }
    }],
    attrs: {
      "type": "number",
      "name": "slideSpeed",
      "id": "slideSpeed"
    },
    domProps: {
      "value": _vm.slideSpeed,
      "value": (_vm.slideSpeed)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.slideSpeed = _vm._n($event.target.value)
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })])]), _vm._v(" "), _vm._m(5)]), _vm._v(" "), _c('hr'), _vm._v(" "), _c('div', {
    staticClass: "row debug-row",
    attrs: {
      "data-equalizer": ""
    }
  }, [_c('div', {
    staticClass: "medium-4 large-4 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('h5', [_vm._v("Update History")]), _vm._v(" "), _c('toggle-switch', {
    attrs: {
      "id": "updateHistory",
      "name": "updateHistory",
      "checked": _vm.updateHistory
    },
    model: {
      value: (_vm.updateHistory),
      callback: function($$v) {
        _vm.updateHistory = $$v
      },
      expression: "updateHistory"
    }
  })], 1)]), _vm._v(" "), _vm._m(6)])])])])])
},staticRenderFns: [function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("By default, at least one pane in an accordion must be open. This can be changed by setting "), _c('small', [_vm._v("allowAllClosed")]), _vm._v(" option to "), _c('small', [_vm._v("true")]), _vm._v(".")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Change the "), _c('small', [_vm._v("deepLink")]), _vm._v(" prop to "), _c('small', [_vm._v("true")]), _vm._v(" to allow users to open a particular accordion panel from URL attribute.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The "), _c('small', [_vm._v("deepLinkSmudge")]), _vm._v(" prop rolls the page up slightly after deep linking so that the accordion is at the top of the viewport.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The "), _c('small', [_vm._v("deepLinkSmudgeDelay")]), _vm._v(" prop adjusts the time before the "), _c('small', [_vm._v("deepLinkSmudge")]), _vm._v(" animation.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("By default, only one pane of an accordion can be open at a time. This can be changed by setting the "), _c('small', [_vm._v("multiExpand")]), _vm._v(" prop to "), _c('small', [_vm._v("true")]), _vm._v(".")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("The "), _c('small', [_vm._v("slideSpeed")]), _vm._v(" prop adjusts the time it takes for an accordion section animation.")])])])
},function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "medium-8 large-8 columns",
    attrs: {
      "data-equalizer-watch": ""
    }
  }, [_c('div', {
    staticClass: "content"
  }, [_c('p', [_vm._v("Change the "), _c('small', [_vm._v("updateHistory")]), _vm._v(" prop to "), _c('small', [_vm._v("true")]), _vm._v(" to modify the browser history via accordion section.")])])])
}]}

/***/ })
],[85]);
//# sourceMappingURL=app.13fd28f1631723ec015c.js.map